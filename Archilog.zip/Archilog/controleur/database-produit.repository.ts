// database-product.repository.ts
import { ProductRepository } from '../modele/produit.repository.ts';
import { Product } from '../modele/produit.ts';
import * as fs from 'node:fs';

export class DatabaseProductRepository implements ProductRepository {
  private readonly filePath: string;

  constructor(filePath: string) {
    this.filePath = filePath;
  }

  private async readProductsFromFile(): Promise<Product[]> {
    return new Promise((resolve, reject) => {
      fs.readFile(this.filePath, 'utf8', (err, data) => {
        if (err) {
          reject(err);
        } else {
          try {
            const products = JSON.parse(data);
            resolve(products);
          } catch (parseError) {
            reject(parseError);
          }
        }
      });
    });
  }

  async createProduct(product: Product): Promise<void> {
    // Logique d'ajout d'un produit à la liste des produits existants
    const products = await this.readProductsFromFile();
    products.push(product);
    await this.writeProductsToFile(products);
  }

  async updateProduct(product: Product): Promise<void> {
    // Logique de mise à jour d'un produit dans la liste des produits existants
    const products = await this.readProductsFromFile();
    const index = products.findIndex(p => p.id === product.id);
    if (index !== -1) {
      products[index] = product;
      await this.writeProductsToFile(products);
    }
  }

  async deleteProduct(productId: string): Promise<void> {
    // Logique de suppression d'un produit de la liste des produits existants
    const products = await this.readProductsFromFile();
    const updatedProducts = products.filter(p => p.id !== productId);
    await this.writeProductsToFile(updatedProducts);
  }

  async getProductById(productId: string): Promise<Product | undefined> {
    // Logique de recherche d'un produit par son identifiant
    const products = await this.readProductsFromFile();
    return products.find(p => p.id === productId);
  }

  async getAllProducts(): Promise<Product[]> {
    // Logique de récupération de tous les produits
    return this.readProductsFromFile();
  }

  private async writeProductsToFile(products: Product[]): Promise<void> {
    return new Promise((resolve, reject) => {
      const data = JSON.stringify(products, null, 2);
      fs.writeFile(this.filePath, data, 'utf8', err => {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
  }
}

