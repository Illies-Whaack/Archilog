import * as fs from 'node:fs';
import { Product } from '../modele/produit.ts';

export class FileHandler {
  private filePath: string;

  constructor(filePath: string) {
    this.filePath = filePath;
  }

  // Méthode pour lire le contenu du fichier
  public readFile(): Promise<string> {
    return new Promise((resolve, reject) => {
      fs.readFile(this.filePath, 'utf8', (err, data) => {
        if (err) {
          reject(err);
          return;
        }
        resolve(data);
      });
    });
  }

  // Méthode pour écrire dans le fichier avec un contenu de type Product
  public write(content: Product): Promise<void> {
    return new Promise((resolve, reject) => {
      const serializedContent = JSON.stringify(content);
      fs.writeFile(this.filePath, serializedContent, 'utf8', (err) => {
        if (err) {
          reject(err);
          return;
        }
        resolve();
      });
    });
  }

  // Méthode pour mettre à jour un produit dans le fichier
  public update(productId: string, updatedProduct: Product): Promise<void> {
    return new Promise((resolve, reject) => {
      // Lire le contenu actuel du fichier
      this.readFile()
        .then((data) => {
          // Analyser les données JSON
          const products: Product[] = JSON.parse(data);
          
          // Rechercher le produit à mettre à jour
          const index = products.findIndex(product => product.id === productId);
          if (index === -1) {
            reject(new Error(`Produit avec l'ID ${productId} introuvable.`));
            return;
          }

          // Mettre à jour le produit
          products[index] = updatedProduct;

          // Réécrire le fichier avec les données mises à jour
          const serializedContent = JSON.stringify(products);
          fs.writeFile(this.filePath, serializedContent, 'utf8', (err) => {
            if (err) {
              reject(err);
              return;
            }
            resolve();
          });
        })
        .catch(reject);
    });
  }

  // Méthode pour supprimer le fichier
  public delete(): Promise<void> {
    return new Promise((resolve, reject) => {
      fs.unlink(this.filePath, (err) => {
        if (err) {
          reject(err);
          return;
        }
        resolve();
      });
    });
  }
}

export default FileHandler;
