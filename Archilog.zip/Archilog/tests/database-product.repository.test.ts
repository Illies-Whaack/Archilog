// database-product.repository.test.ts
import { DatabaseProductRepository } from "../controleur/database-produit.repository.ts";
import { Product } from "../modele/produit.ts";
import * as fs from "node:fs";
import jest from 'jest';
import { beforeEach, describe, it, expect, afterEach } from "jest";

describe("DatabaseProductRepository", () => {
  const repository = new DatabaseProductRepository("test-products.json");

  beforeEach(async () => {
    // Avant chaque test, assurez-vous que le fichier test-products.json est réinitialisé avec des données de test.
    await resetTestFile();
  });

  afterEach(async () => {
    // Après chaque test, nettoyez le fichier test-products.json.
    await resetTestFile();
  });

  it("should create a product", async () => {
    const product: Product = {
      id: "1",
      name: "Test Product",
      description: "Description",
      price: 10.99,
    };
    await repository.createProduct(product);
    const products = await repository.getAllProducts();
    expect(products).toHaveLength(1);
    expect(products[0]).toEqual(product);
  });

  it("should update a product", async () => {
    const initialProduct: Product = {
      id: "1",
      name: "Initial Product",
      description: "Description",
      price: 10.99,
    };
    await repository.createProduct(initialProduct);
    const updatedProduct: Product = {
      id: "1",
      name: "Updated Product",
      description: "Updated Description",
      price: 15.99,
    };
    await repository.updateProduct(updatedProduct);
    const products = await repository.getAllProducts();
    expect(products).toHaveLength(1);
    expect(products[0]).toEqual(updatedProduct);
  });

  it("should delete a product", async () => {
    const product: Product = {
      id: "1",
      name: "Test Product",
      description: "Description",
      price: 10.99,
    };
    await repository.createProduct(product);
    await repository.deleteProduct("1");
    const products = await repository.getAllProducts();
    expect(products).toHaveLength(0);
  });

  // Ajoutez d'autres tests pour les autres méthodes du repository
});

async function resetTestFile() {
  // Réinitialise le fichier test-products.json avec des données de test initiales.
  const initialData = [{
    id: "0",
    name: "Initial Product",
    description: "Description",
    price: 0,
  }];
  await fs.promises.writeFile(
    "test-products.json",
    JSON.stringify(initialData),
    "utf8",
  );
}
