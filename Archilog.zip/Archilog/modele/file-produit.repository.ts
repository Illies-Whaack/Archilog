import { ProductRepository } from './produit.repository.ts';
import { Product } from './produit.ts';
import { FileHandler } from '../controleur/file-handler.ts'; // Supposons que vous avez une classe de manipulation de fichiers

export class FileProductRepository implements ProductRepository {
  constructor(private fileHandler: FileHandler) {}

  async createProduct(product: Product): Promise<void> {
    await this.fileHandler.write(product);
  }

  async updateProduct(product: Product): Promise<void> {
    await this.fileHandler.update(product);
  }

  async deleteProduct(productId: Product): Promise<void> {
    await this.fileHandler.delete(productId);
  }

  async getProductById(productId: string): Promise<Product | undefined> {
    return await this.fileHandler.getById(productId);
  }

  async getAllProducts(): Promise<Product[]> {
    return await this.fileHandler.getAll();
  }
}
