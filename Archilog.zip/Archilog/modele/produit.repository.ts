import { Product } from './produit.ts';

export interface ProductRepository {
  createProduct(product: Product): Promise<void>;
  updateProduct(product: Product): Promise<void>;
  deleteProduct(productId: string): Promise<void>;
  getProductById(productId: string): Promise<Product | undefined>;
  getAllProducts(): Promise<Product[]>;
}
