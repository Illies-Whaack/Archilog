class VueInventaire {
    init():void {
    location.href = "infraction_liste.html";
    }
    }
    let vueInventaire = new VueInventaire;
    vueInventaire.init();