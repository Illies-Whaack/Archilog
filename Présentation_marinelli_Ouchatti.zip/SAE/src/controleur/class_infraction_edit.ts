import { UneInfr, LesInfrs } from "../modele/data_infraction.js"
import { UnCond, LesConds } from "../modele/data_conducteur.js"
import { UnVehic, LesVehics } from "../modele/data_vehicule"
import { UnDelitByInfraction, LesDelits, LesDelitsByInfraction, UnDelit, TDelitsByInfraction } from "../modele/data_delit.js"

type TStatutValeur = 'correct' | 'vide' | 'inconnu' | 'doublon'
type TErreur = { statut: TStatutValeur, msg: { [key in TStatutValeur]: string } }
type TInfractionEditForm = {
    divDetail: HTMLElement, divTitre: HTMLElement
    , edtNum: HTMLInputElement, edtDate: HTMLInputElement, edtImmat: HTMLInputElement, edtPermis: HTMLInputElement
    , btnRetour: HTMLInputElement, btnValider: HTMLInputElement, btnAnnuler: HTMLInputElement, btnAjouterDelit: HTMLInputElement
    , lblImmatErreur: HTMLLabelElement, lblDelitByInfErreur: HTMLLabelElement, lblErreurDate: HTMLLabelElement
    , lblDetailInfraction1: HTMLLabelElement, lblDetailInfraction2: HTMLLabelElement, lblDetailInfraction3: HTMLLabelElement
    , divInfractionDelit: HTMLDivElement, divInfractionDelitEdit: HTMLDivElement
    , lblTotal: HTMLLabelElement, tableDelits: HTMLTableElement
    , listeDelits: HTMLSelectElement,
}

class VueInfractionEdit {
    private _form: TInfractionEditForm
    private _params: string[]; // paramètres reçus par le fichier HTML
    // tel que params[0] : mode affi, modif, suppr, ajout
    // params[1] : id en mode affi, modif, suppr
    private _grille: TDelitsByInfraction; // tableau des équipements de la salle
    private _erreur: {
        // tableau contenant les messages d'erreur pour chaque type d'erreur pour chaque zone de saisie à vérifier
        [key: string]: TErreur
    }
    get form(): TInfractionEditForm { return this._form }
    get params(): string[] { return this._params }
    get grille(): TDelitsByInfraction { return this._grille }
    get erreur(): { [key: string]: TErreur } { return this._erreur }

    initMsgErreur(): void {
        // les erreurs "champ vide", "valeur inconnue", "doublon"
        //sont les trois principales erreurs dans un formulaire
        // pour chaque champ à contrôler (événement onChange),
        //création des 3 messages d'erreur + message pour correct
        // avec chaîne vide si pas d'erreur générée pour un type d'erreur potentielle
        this._erreur = {

            edtImmat: {
                statut: 'vide'
                , msg: {
                    correct: ""
                    , vide: "L'immatriculation doit être renseignée."
                    , inconnu: "Immatriculation inconnue"
                    , doublon: ""
                }
            }
            , listeDelits: {
                statut: 'vide'
                , msg: {
                    correct: ""
                    , vide: "L'infraction doit comporter au moins un délit."
                    , inconnu: ""
                    , doublon: ""
                }
            }
            , edtPermis: {
                statut: 'vide'
                , msg: {
                    correct: ""
                    , vide: ""
                    , inconnu: "Le vehicule est inconnu"
                    , doublon: ""
                }
            }
            , edtDate: {
                statut: 'vide'
                , msg: {
                    correct: ""
                    , vide: "La date saisie n'est pas valide"
                    , inconnu: ""
                    , doublon: ""
                }
            }
        }
    }

    init(form: TInfractionEditForm): void {
        this._form = form;
        this._params = location.search.substring(1).split('&');
        // params[0] : mode affi, modif, suppr, ajout
        // params[1] : id en mode affi, modif, suppr
        this.form.divInfractionDelitEdit.hidden = true;
        this.initMsgErreur();
        let titre: string;
        switch (this.params[0]) {
            case 'suppr': titre = "Suppression d'une infraction"; break;
            case 'ajout': titre = "Nouvelle infraction"; break;
            case 'modif': titre = "Modification d'une infraction"; break;
            default: titre = "Détail d'une infraction";
        }
        this.form.divTitre.textContent = titre;
        const lesInfrs = new LesInfrs;
        const affi = this.params[0] === 'affi';
        if (this.params[0] !== 'ajout') { // affi ou modif ou suppr
            const infr = lesInfrs.byIdInf(this._params[1]);
            this.form.edtNum.value = infr.idInf;
            this.form.edtDate.value = infr.dateInf;
            this.form.edtImmat.value = infr.noImmat;
            this.form.edtPermis.value = infr.noPermis;
            this.form.edtNum.readOnly = true;
            this.form.edtDate.readOnly = true;
            this.form.edtImmat.readOnly = affi;
            this.form.edtPermis.readOnly = affi;
            this.detailInfraction1(infr.noImmat)
            this.detailInfraction3(infr.noPermis);
        }

        if (this.params[0] === 'affi') {
            this.form.btnAjouterDelit.hidden = true
        }
        
        this.affiDetail();
        if (this.params[0] === 'suppr') {
            // temporisation 1 seconde pour afficher les données de la salle avant demande de confirmation de la supression
            setTimeout(() => { this.supprimer(this.params[1]) }, 1000);
        }

        if (this.params[0] === 'ajout') {
            const lesInfrs = new LesInfrs;
            let exist = true;
            let randomNum;
            while (exist) {
                randomNum = Math.floor(Math.random() * 100); // génère un nombre aléatoire entre 0 et 99
                exist = lesInfrs.idExiste(randomNum.toString());
                if (exist !== true) { // vérifie si le nombre existe déjà dans votre base de données
                    this.form.edtNum.value = randomNum.toString();
                    this.form.edtNum.readOnly = true;
                }
            }
            let d = new Date();
            this.form.edtDate.valueAsDate = d;

        }
        this.form.btnRetour.hidden = !affi;
        this.form.btnValider.hidden = affi;
        this.form.btnAnnuler.hidden = affi;


        this.form.edtImmat.onchange = function (): void { vueInfractionEdit.detailInfraction1(vueInfractionEdit.form.edtImmat.value); }
        this.form.edtPermis.onchange = function (): void { vueInfractionEdit.detailInfraction3(vueInfractionEdit.form.edtPermis.value); }
        this.form.btnRetour.onclick = function (): void { vueInfractionEdit.retourClick(); }
        this.form.btnAnnuler.onclick = function (): void { vueInfractionEdit.retourClick(); }
        this.form.btnValider.onclick = function (): void { vueInfractionEdit.validerClick(); }
        this.form.btnAjouterDelit.onclick = function (): void { vueInfractionEdit.ajouterDelitClick(); }
        this.form.listeDelits.onclick = function (): void { vueInfractionEdit.validerDelitClick(); }
    }

    detailInfraction1(valeur: string): void {

        const err = this.erreur.edtImmat
        const lesVehic = new LesVehics;
        let detail = this.form.lblDetailInfraction2;
        detail.textContent = "";
        err.statut = "correct";
        let chaine: string = valeur.trim();
        if (chaine.length > 0) {
            const vehic: UnVehic = lesVehic.byNoImmat(chaine);
            if (vehic.noImmat !== "") { // département trouvé
                const date = new Date(vehic.dateImmat);
                const dateFR = date.toLocaleDateString('fr-FR');
                detail.textContent
                    = vehic.Marque + " " + vehic.Modele + "\r\n" + "immatriculé le " + dateFR;
            }
            else {
                err.statut = 'inconnu';
                detail.textContent = err.msg.inconnu;
            }
        }
        else err.statut = 'vide';

        detail = this.form.lblDetailInfraction1;
        detail.textContent = "";
        chaine = valeur.trim();
        if (chaine.length > 0) {
            const vehic: UnVehic = lesVehic.byNoImmat(chaine);
            if (vehic.noImmat !== "") { // département trouvé
                const date = new Date(vehic.datePermis);
                const dateFR = date.toLocaleDateString('fr-FR');
                detail.textContent
                    = "propriétaire : " + "\r\n" + vehic.nom + " " + vehic.prenom + "\r\n" + "permis obtenu le " + dateFR;
            }
        }
    }

    detailInfraction3(valeur: string): void {
        const err = this.erreur.edtPermis
        const lesConds = new LesConds;
        const detail = this.form.lblDetailInfraction3;
        detail.textContent = "";
        err.statut = "correct";
        const chaine: string = valeur.trim();
        if (chaine.length > 0) {
            const cond: UnCond = lesConds.ByNoPermis(chaine);
            if (cond.noPermis !== "") { // département trouvé
                const date = new Date(cond.datePermis);
                const dateFR = date.toLocaleDateString('fr-FR');
                detail.textContent
                    = cond.Nom + " " + cond.Prenom + "\r\n" + "permis obtenu le " + dateFR;
            }
            else {
                err.statut = 'inconnu';
                detail.textContent = err.msg.inconnu;
            }
        }
        else err.statut = 'vide';
    }

    affiDetail(): void {
        const lesDelitsByInfraction = new LesDelitsByInfraction();
        this._grille = lesDelitsByInfraction.byIdInf(this.params[1]);

        console.log(this.grille)
        this.affiGrilleDetail();
    }
    affiGrilleDetail(): void {
        while (this.form.tableDelits.rows.length > 1) { this.form.tableDelits.rows[1].remove(); }
        let total = 0;
        for (let id in this.grille) {

            const unDelitByInfraction: UnDelitByInfraction = this.grille[id];
            const tr = this.form.tableDelits.insertRow();
            tr.insertCell().textContent = unDelitByInfraction.unDelit.Nature;
            tr.insertCell().textContent = unDelitByInfraction.tarif;
            const affi = this.params[0] === 'affi';
            if (!affi) {
                const modif = this.params[0] === 'modif';
                let balisea: HTMLAnchorElement; // déclaration balise <a>
                if (!modif) {
                    const ajout = this.params[0] === 'ajout';
                    if (!ajout) {
                        // création balise <a> pour appel modification équipement dans salle

                    }
                }
                // création balise <a> pour appel suppression équipement dans salle
                balisea = document.createElement("a")
                balisea.classList.add('img_corbeille')
                balisea.onclick = function (): void { vueInfractionEdit.supprimerDelitClick(id); }
                tr.insertCell().appendChild(balisea)
            }
            total += Number(unDelitByInfraction.tarif)
        }
        this.form.lblTotal.textContent = total.toString();
    }
    supprimer(idInf: string): void {
        if (confirm("Confirmez-vous la suppression de l'infraction ?" + idInf)) {
            let lesDelitsByInfraction: LesDelitsByInfraction = new LesDelitsByInfraction();
            lesDelitsByInfraction.delete(idInf); // suppression dans la base des equipements de la salle
            const lesInfrs = new LesInfrs;
            lesInfrs.delete(idInf); // suppression dans la base de la salle
        }
        this.retourClick();
    }

    verifImmat(valeur: string): void {
        const lesVehics = new LesVehics;
        const err = this.erreur.edtImmat
        err.statut = "correct";
        const chaine: string = valeur.trim();
        if (chaine.length > 0) {
            if (!chaine.match(/^([a-zA-Z0-9]+)$/)) {
                // expression régulière qui teste si la chaîne ne contient rien d'autre
                // que des caractères alphabétiques minuscules ou majuscules et des chiffres
                this.erreur.edtImmat.statut = 'inconnu';
            }
            else if ((this.params[0] === 'ajout') && (lesVehics.idExiste(chaine))) {
                this.erreur.edtImmat.statut = 'doublon';
            }
        }
        else err.statut = 'vide';
    }

    verifListeDelit(): void {
        const err = this._erreur.listeDelits
        err.statut = "correct";
        const cible = this._form.listeDelits;
        if (cible.value === "") {
            err.statut = 'vide'
        }
    }

    verifDate(): void {
        const err = this._erreur.edtDate
        err.statut = "correct";
        const cible = this._form.edtDate;
        let d = new Date
        if ((cible.valueAsDate >= d ) || (cible.value === "") ) {
            err.statut = 'vide'
        }
    }

    traiteErreur(uneErreur: TErreur, zone: HTMLElement): boolean {
        let correct = true;
        zone.textContent = "";
        if (uneErreur.statut !== "correct") { // non correct ==> erreur
            if (uneErreur.msg[uneErreur.statut] !== '') { // erreur
                zone.textContent = uneErreur.msg[uneErreur.statut];
                correct = false;
            }
        }
        return correct;
    }

    validerClick(): void {
        let correct = true;
        this.verifImmat(this._form.edtImmat.value);
        this.verifListeDelit();
        this.verifDate();
        if (JSON.stringify(this.grille) === '{}') { this._erreur.listeDelits.statut = 'vide' }
        else this._erreur.listeDelits.statut = "correct";
        correct = this.traiteErreur(this._erreur.edtImmat, this.form.lblImmatErreur) && correct;
        correct = this.traiteErreur(this._erreur.listeDelits, this.form.lblDelitByInfErreur) && correct;
        correct = this.traiteErreur(this._erreur.edtDate, this.form.lblErreurDate) && correct;

        if (this.form.edtDate.value <= this.form.edtDate.valueAsDate.toDateString()) {
            correct = this.traiteErreur(this._erreur.edtDate, this.form.lblErreurDate) && correct;
        }
        const lesInfrs = new LesInfrs;
        const infr = new UneInfr;
        if (correct) {
            infr.idInf = this.form.edtNum.value;
            infr.dateInf = this.form.edtDate.value;
            infr.noImmat = this.form.edtImmat.value;
            infr.noPermis = this.form.edtPermis.value;
            if (this._params[0] === 'ajout') {
                lesInfrs.insert(infr);
            }
            else {
                lesInfrs.update(infr);
            }
            const lesDelitsByInfraction: LesDelitsByInfraction = new LesDelitsByInfraction;
            lesDelitsByInfraction.delete(infr.idInf);
            lesDelitsByInfraction.insert(infr.idInf, this.grille);
            this.retourClick();
        }
    }
    retourClick(): void {
        location.href = "infraction_liste.html";
    }

    ajouterDelitClick(): void {
        this.afficherDelitEdit();
        // réinitialiser la liste des équipements à choisir
        this.form.listeDelits.length = 0;
        const lesDelits = new LesDelits;
        const data = lesDelits.all();
        const idDelits = [];
        for (let i in this._grille) {
            idDelits.push(this._grille[i].unDelit.idDelit);
        }
        for (let i in data) {
            const id = data[i].idDelit;
            if (idDelits.indexOf(id) === -1) { // pas dans la liste des équipements déjà dans la salle
                this._form.listeDelits.options.add(new Option(data[i].Nature, id)); // text, value
            }
        }
    }

    supprimerDelitClick(id: string): void {
        if (confirm("Confirmez-vous le retrait de l'équipement de l'infraction ? ")) {
            delete (this._grille[id]);
            this.affiGrilleDetail();
        }
    }

    afficherDelitEdit(): void {
        this.form.divInfractionDelitEdit.hidden = false;
        this.form.divDetail.style.pointerEvents = 'none';
        this.form.divInfractionDelitEdit.style.pointerEvents = 'auto';
        this.form.btnAnnuler.hidden = true;
        this.form.btnValider.hidden = true;
    }
    cacherDelitEdit(): void {
        this.form.divInfractionDelitEdit.hidden = true;
        this.form.divDetail.style.pointerEvents = 'auto';
        this.form.btnAnnuler.hidden = false;
        this.form.btnValider.hidden = false;
    }

    validerDelitClick(): void {
        let correct = true;
        this.verifListeDelit();
        correct = this.traiteErreur(this._erreur.listeDelits, this.form.lblDelitByInfErreur) && correct;
        if (correct) {
            const lesDelits = new LesDelits;
            // ajout visuel de la ligne dans la grille tabulaire de la liste des équipements d'une salle
            const unDelit: UnDelit = lesDelits.byIdDelit(this._form.listeDelits.value);
            const unDelitByInfraction: UnDelitByInfraction
                = new UnDelitByInfraction(unDelit, unDelit.Tarif);
            this._grille[unDelit.Nature] = unDelitByInfraction;
            this.affiGrilleDetail();
            this.annulerDelitClick();
        }
    }

    annulerDelitClick(): void {
        this.cacherDelitEdit();
    }

}
let vueInfractionEdit = new VueInfractionEdit;
export { vueInfractionEdit }
