import { UneInfr, LesInfrs } from "../modele/data_infraction.js"
import { LesConds } from "../modele/data_conducteur.js"


type TInfrListeForm = {
    divTitre: HTMLElement, btnAjouter: HTMLInputElement, tableInfr: HTMLTableElement
}
class VueInfrListe {
    private _form: TInfrListeForm;
    get form(): TInfrListeForm { return this._form }

    init(form: TInfrListeForm): void {
        this._form = form;
        const lesInfrs = new LesInfrs;
        const lesConds = new LesConds();
        const data = lesInfrs.all();
        this.form.divTitre.textContent = 'Liste des infractions'; // construction du titre
        for (let num in data) {
            const uneInfr: UneInfr = data[num];
            const date = new Date(uneInfr.dateInf);
            const dateFR = date.toLocaleDateString('fr-FR');
            uneInfr.dateInf = dateFR
            const tr = this.form.tableInfr.insertRow(); // création nlle ligne dans tableau
            let balisea: HTMLAnchorElement; // déclaration balise <a>
            // création balise <a> pour appel page visualisation du détail de la salle
            balisea = document.createElement("a")
            balisea.classList.add('img_visu') // définition class contenant l’image (voir css)
            balisea.onclick = function (): void { vueInfrListe.detailInfrClick(uneInfr.idInf); }
            tr.insertCell().appendChild(balisea) // création nlle cellule dans ligne
            tr.insertCell().textContent = uneInfr.idInf;
            tr.insertCell().textContent = uneInfr.dateInf
            tr.insertCell().textContent = uneInfr.noImmat;
            tr.insertCell().textContent = lesConds.ByNoPermis(uneInfr.noPermis).noPermis + " " + lesConds.ByNoPermis(uneInfr.noPermis).Prenom + " " + lesConds.ByNoPermis(uneInfr.noPermis).Nom;
            tr.insertCell().textContent = ""
            tr.insertCell().textContent = uneInfr.Montant;
            // création balise <a> pour appel page modification du détail de la salle
            balisea = document.createElement("a")
            balisea.classList.add('img_modification') // définition class contenant l’image (voir css)
            balisea.onclick = function (): void { vueInfrListe.modifierInfrClick(uneInfr.idInf); }
            tr.insertCell().appendChild(balisea)
            // création balise <a> pour appel page suppression d'une salle
            balisea = document.createElement("a")
            balisea.classList.add('img_corbeille') // définition class contenant l’image (voir css)
            balisea.onclick = function (): void { vueInfrListe.supprimerInfrClick(uneInfr.idInf); }
            tr.insertCell().appendChild(balisea)
        }
        // définition événement onclick sur bouton "ajouter"
        this.form.btnAjouter.onclick = function (): void { vueInfrListe.ajouterInfrClick(); }
    }

    detailInfrClick(num: string): void {
        // redirection vers « salle_edit.html »avec indication du statut « affi » et du numéro de salle
        location.href = "infraction_edit.html?affi&" + encodeURIComponent(num);
    }
    modifierInfrClick(num: string): void {
        // redirection vers « salle_edit.html »avec indication du statut « modif » et du numéro de salle
        location.href = "infraction_edit.html?modif&" + encodeURIComponent(num)
    }
    supprimerInfrClick(num: string): void {
        // redirection vers « salle_edit.html »avec indication du statut »suppr » et du numéro de salle
        location.href = "infraction_edit.html?suppr&" + encodeURIComponent(num)
    }
    ajouterInfrClick(): void {
        // redirection vers « salle_edit.html »avec indication du statut « ajout »
        location.href = "infraction_edit.html?ajout"
    }
}

let vueInfrListe = new VueInfrListe;
export { vueInfrListe }