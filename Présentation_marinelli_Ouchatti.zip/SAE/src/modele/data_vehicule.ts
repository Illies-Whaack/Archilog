import { connexion, APIsql } from "../modele/connexion.js"

export class ErreurImmat extends Error {
    constructor(message:string){
        super(message)
        this.name = ("ErreurImmat")
    }
 }

export class ErreurDate extends Error {
    constructor(message:string){
        super(message)
        this.name = ("ErreurDate")
    }
 }

 export class ErreurMarque extends Error {
    constructor(message:string){
        super(message)
        this.name = ("ErreurMarque")
    }
 }

 export class ErreurModele extends Error {
    constructor(message:string){
        super(message)
        this.name = ("ErreurModele")
    }
 }

 export class ErreurPermis extends Error {
    constructor(message:string){
        super(message)
        this.name = ("ErreurPermis")
    }
 }

export class UnVehic { // définition de la classe gérant les données d’un département
    private _noImmat: string;
    private _dateImmat: string;
    private _Modele: string;
    private _Marque: string;
    private _noPermis: string;
    private _nom : string
    private _prenom :string
    private _datePermis: string
    constructor(no_immat = "", date_immat = "", modele = "", marque = "", no_permis = "", nom  = "", prenom = "", date_permis = "") {
        // initialisation à l’instanciation
        this._noImmat = no_immat;
        this._dateImmat = date_immat;
        this._Modele = modele;
        this._Marque = marque;
        this._noPermis = no_permis;
        this._nom = nom
        this._prenom = prenom
        this._datePermis = date_permis
    }
    // définition des « getters » et des « setters » pour la lecture/écriture des attributs privés de la classe
    get noImmat(): string { return this._noImmat; }
    set noImmat(no_immat: string) { 
        if(no_immat[0].match(/^([a-zA-Z]+)$/)){
            if(no_immat[1].match(/^([a-zA-Z]+)$/)){
                if(no_immat[2].match(/^([0-9]+)$/)){
                    if(no_immat[3].match(/^([0-9]+)$/)){
                        if(no_immat[4].match(/^([a-zA-Z]+)$/)){
                            if(no_immat[5].match(/^([a-zA-Z]+)$/)){
                                this._noImmat = no_immat;
                            }else{
                                throw new ErreurImmat("L'immatriculation n'est pas du bon format !");
                            }
                        }else{
                            throw new ErreurImmat("L'immatriculation n'est pas du bon format !");
                        }
                    }else{
                        throw new ErreurImmat("L'immatriculation n'est pas du bon format !");
                    }
                }else{
                    throw new ErreurImmat("L'immatriculation n'est pas du bon format !");
                }
            }else{
                throw new ErreurImmat("L'immatriculation n'est pas du bon format !");
            }
        }else{
            throw new ErreurImmat("L'immatriculation n'est pas du bon format !");
        }
     }
    get dateImmat(): string { return this._dateImmat; }
    set dateImmat(date_immat: string) { 
        let tab = date_immat.split("-");
        if (tab.length != 3){
            throw new ErreurDate("La date n'est pas au bon format !")
        }
        let jour = parseInt(tab[2]);
        if (jour < 1 || jour > 31){
            throw new ErreurDate("La date n'est pas au bon format !")
        }
        let mois = parseInt(tab[1]);
        if (mois < 1 || mois > 12){
            throw new ErreurDate("La date n'est pas au bon format !")
        }
        let année = parseInt(tab[0]);
        if (année < 1 || année > 9999){
            throw new ErreurDate("La date n'est pas au bon format !")
        }
        for (let i = 0;i<tab[0].length - 1; i++){
            if (!tab[0][i].match(/^([0-9]+)$/)){
            throw new ErreurDate("La date n'est pas au bon format !")
            }
        }
        for (let i = 0;i<tab[1].length - 1; i++){
            if (!tab[1][i].match(/^([0-9]+)$/)){
            throw new ErreurDate("La date n'est pas au bon format !")
            }
        }
        for (let i = 0;i<tab[2].length - 1; i++){
            if (!tab[2][i].match(/^([0-9]+)$/)){
            throw new ErreurDate("La date n'est pas au bon format !")
            }
        }
        this._dateImmat = date_immat;
     }
    get Modele(): string { return this._Modele; }
    set Modele(modele: string) { 
        if (modele.length < 2){
            throw new ErreurModele("Le modele n'est pas au bon format !") 
        }
        for (let i = 0; i < modele.length - 1; i++){
            if (!modele[i].match(/^([a-zA-Z0-9" "-]+)$/)){
                throw new ErreurModele("Le modele n'est pas au bon format !") 
            }
        }
        this._Modele = modele
    }
    get Marque(): string { return this._Marque; }
    set Marque(marque: string) { 
        if (marque.length < 4){
            throw new ErreurMarque("La marque n'est pas au bon format !") 
        }
        for (let i = 0; i < marque.length - 1; i++){
            if (!marque[i].match(/^([a-zA-Zà-Ŋ" "]+)$/)){
                throw new ErreurMarque("La marque n'est pas au bon format !") 
            }
        }
        this._Marque = marque
    }
    get nom(): string { return this._nom; }
    set nom(nom: string) { this._nom = nom; }
    get noPermis(): string { return this._noPermis; }
    set noPermis(no_permis: string) { 
        if(no_permis[0].match(/^([a-zA-Z]+)$/)){
            if(no_permis[1].match(/^([a-zA-Z]+)$/)){
                if(no_permis[2].match(/^([0-9]+)$/)){
                    if(no_permis[3].match(/^([0-9]+)$/)){
                        this._noPermis = no_permis
                    }else{
                        throw new ErreurPermis("Le numéro permis n'est pas au bon format !")
                    }
                }else{
                    throw new ErreurPermis("Le numéro permis n'est pas au bon format !")
                }
            }else{
                throw new ErreurPermis("Le numéro permis n'est pas au bon format !")
            }
        }else{
            throw new ErreurPermis("Le numéro permis n'est pas au bon format !")
        }
     }
    get prenom(): string { return this._prenom; }
    set prenom(prenom: string) { this._prenom = prenom; }
    get datePermis(): string { return this._datePermis; }
    set datePermis(date_permis: string) { this._datePermis = date_permis; }

    toArray(): APIsql.TtabAsso { // renvoie l’objet sous la forme d’un tableau associatif
        // pour un affichage dans une ligne d’un tableau HTML
        let tableau: APIsql.TtabAsso = { 'noImmat': this.noImmat, 'dateImmat': this.dateImmat, 'Modele': this.Modele, 'Marque': this.Marque, 'noPermis': this.noPermis, 'nom':this.nom, 'prenom': this.prenom, 'datePermis': this.datePermis };
        return tableau;
    }
}

type TVehics = { [key: string]: UnVehic };

class LesVehics { // définition de la classe gérant les données de la table DEPARTEMENT
    constructor() {
        // rien
    }

    idExiste(no_immat: string): boolean {
        // renvoie le test d’existence d’une salle dans la table
        // sert pour l’ajout d’une nouvelle salle
        return (APIsql.sqlWeb.SQLloadData("SELECT no_immat FROM vehicule WHERE no_immat=?"
            , [no_immat]).length > 0);
    }

    private load(result: APIsql.TdataSet): TVehics {
        // à partir d’un TdataSet, conversion en tableau d’objets UnDept
        const vehics: TVehics = {};
        for (let i = 0; i < result.length; i++) {
            const item: APIsql.TtabAsso = result[i];
            const vehic = new UnVehic(item['no_immat'], item['date_immat'], item['modele'], item['marque'], item['no_permis'],  item['nom'],  item['prenom'],  item['date_permis'] );
            vehics[vehic.noImmat] = vehic; // clé d’un élément du tableau : code dépt
        }
        return vehics;
    }
    private prepare(where: string): string { // préparation de la requête avec ou sans restriction (WHERE)
        let sql: string;
        sql = "SELECT no_immat, date_immat, modele, marque, vehicule.no_permis, nom, prenom, date_permis FROM vehicule, conducteur ";
        if (where !== "") {
            sql += " WHERE vehicule.no_permis = conducteur.no_permis AND " + where;
        }
        return sql;
    }
    all(): TVehics { // renvoie le tableau d’objets contenant tous les départements
        return this.load(APIsql.sqlWeb.SQLloadData(this.prepare(""), []));
    }

    byNoImmat(no_immat: string): UnVehic { // renvoie l’objet correspondant au département code_dept
        let vehic = new UnVehic;
        const vehics: TVehics =
            this.load(APIsql.sqlWeb.SQLloadData(this.prepare("no_immat = ?"), [no_immat]));
        const lesCles: string[] = Object.keys(vehics);
        // affecte les clés du tableau associatif « depts » dans le tableau de chaines « lesCles »
        if (lesCles.length > 0) {
            vehic = vehics[lesCles[0]]; // récupérer le 1er élément du tableau associatif « depts »
        }
        return vehic;
    }
    toArray(vehics: TVehics): APIsql.TdataSet {
        // renvoie le tableau d’objets sous la forme d’un tableau de tableaux associatifs
        // pour un affichage dans un tableau HTML
        let T: APIsql.TdataSet = [];
        for (let id in vehics) {
            T.push(vehics[id].toArray());
        }
        return T;
    }
}
export { connexion }
export { LesVehics }
export { TVehics }