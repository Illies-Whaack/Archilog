import { connexion, APIsql } from "../modele/connexion.js"
export class ErreurId extends Error {
    constructor(message: string) {
        super(message)
        this.name = ("ErreurId")
    }
}

export class ErreurDate extends Error {
    constructor(message: string) {
        super(message)
        this.name = ("ErreurDate")
    }
}

export class ErreurImmat extends Error {
    constructor(message: string) {
        super(message)
        this.name = ("ErreurImmat")
    }
}

export class ErreurPermis extends Error {
    constructor(message: string) {
        super(message)
        this.name = ("ErreurPermis")
    }
}

export class UneInfr {
    private _idInf: string
    private _dateInf: string;
    private _noImmat: string;
    private _noPermis: string;
    private _Montant: string

    constructor(id_inf = "", date_inf = "", no_immat = "", no_permis = "", montant = "") {
        this._idInf = id_inf
        this._dateInf = date_inf
        this._noImmat = no_immat
        this._noPermis = no_permis
        this._Montant = montant
    }

    get idInf(): string { return this._idInf; }
    set idInf(id_inf: string) {
        if (Number.isInteger(id_inf)) {
            this._idInf = id_inf;
        } else {
            throw new ErreurId("L'Id doit etre un entier !")
        }
    }
    get dateInf(): string { return this._dateInf; }
    set dateInf(date_inf: string) {
        let tab = date_inf.split("-");
        if (tab.length != 3) {
            throw new ErreurDate("La date n'est pas au bon format !")
        }
        let jour = parseInt(tab[2]);
        if (jour < 1 || jour > 31) {
            throw new ErreurDate("La date n'est pas au bon format !")
        }
        let mois = parseInt(tab[1]);
        if (mois < 1 || mois > 12) {
            throw new ErreurDate("La date n'est pas au bon format !")
        }
        let année = parseInt(tab[0]);
        if (année < 1 || année > 9999) {
            throw new ErreurDate("La date n'est pas au bon format !")
        }
        for (let i = 0; i < tab[0].length - 1; i++) {
            if (!tab[0][i].match(/^([0-9]+)$/)) {
                throw new ErreurDate("La date n'est pas au bon format !")
            }
        }
        for (let i = 0; i < tab[1].length - 1; i++) {
            if (!tab[1][i].match(/^([0-9]+)$/)) {
                throw new ErreurDate("La date n'est pas au bon format !")
            }
        }
        for (let i = 0; i < tab[2].length - 1; i++) {
            if (!tab[2][i].match(/^([0-9]+)$/)) {
                throw new ErreurDate("La date n'est pas au bon format !")
            }
        }
        this._dateInf = date_inf;
    }
    get noImmat(): string { return this._noImmat; }
    set noImmat(no_immat: string) {
        if (no_immat[0].match(/^([a-zA-Z]+)$/)) {
            if (no_immat[1].match(/^([a-zA-Z]+)$/)) {
                if (no_immat[2].match(/^([0-9]+)$/)) {
                    if (no_immat[3].match(/^([0-9]+)$/)) {
                        if (no_immat[4].match(/^([a-zA-Z]+)$/)) {
                            if (no_immat[5].match(/^([a-zA-Z]+)$/)) {
                                this._noImmat = no_immat;
                            } else {
                                throw new ErreurImmat("L'immatriculation n'est pas du bon format !");
                            }
                        } else {
                            throw new ErreurImmat("L'immatriculation n'est pas du bon format !");
                        }
                    } else {
                        throw new ErreurImmat("L'immatriculation n'est pas du bon format !");
                    }
                } else {
                    throw new ErreurImmat("L'immatriculation n'est pas du bon format !");
                }
            } else {
                throw new ErreurImmat("L'immatriculation n'est pas du bon format !");
            }
        } else {
            throw new ErreurImmat("L'immatriculation n'est pas du bon format !");
        }
    }
    get noPermis(): string { return this._noPermis; }
    set noPermis(no_permis: string) {
        if (no_permis[0].match(/^([a-zA-Z]+)$/)) {
            if (no_permis[1].match(/^([a-zA-Z]+)$/)) {
                if (no_permis[2].match(/^([0-9]+)$/)) {
                    if (no_permis[3].match(/^([0-9]+)$/)) {
                        this._noPermis = no_permis
                    } else {
                        throw new ErreurPermis("Le numéro permis n'est pas au bon format !")
                    }
                } else {
                    throw new ErreurPermis("Le numéro permis n'est pas au bon format !")
                }
            } else {
                throw new ErreurPermis("Le numéro permis n'est pas au bon format !")
            }
        } else {
            throw new ErreurPermis("Le numéro permis n'est pas au bon format !")
        }
    }
    get Montant(): string { return this._Montant; }
    set Montant(montant: string) { this._Montant = montant; }

    toArray(): APIsql.TtabAsso { // renvoie l’objet sous la forme d’un tableau associatif
        // pour un affichage dans une ligne d’un tableau HTML
        let tableau: APIsql.TtabAsso = {
            'idInf': this.idInf, 'dateInf': this.dateInf,
            'noImmat': this.noImmat, 'noPermis': this.noPermis, 'Montant': this.Montant
        };
        return tableau;
    }
}

type TInfrs = { [key: string]: UneInfr };

class LesInfrs {
    constructor() {
        //rien
    }

    idExiste(id_inf: string): boolean {
        // renvoie le test d’existence d’une salle dans la table
        // sert pour l’ajout d’une nouvelle salle
        return (APIsql.sqlWeb.SQLloadData("SELECT id_inf FROM infraction WHERE id_inf=?"
            , [id_inf]).length > 0);
    }

    private load(result: APIsql.TdataSet): TInfrs {

        const infrs: TInfrs = {};
        for (let i = 0; i < result.length; i++) {
            const item: APIsql.TtabAsso = result[i];
            const infr = new UneInfr(item['id_inf'], item['date_inf'], item['no_immat'], item['no_permis'], item['montant']);
            infrs[infr.idInf] = infr;
        }
        return infrs;
    }

    private prepare(where: string): string { // préparation de la requête avec ou sans restriction (WHERE)
        let sql: string;
        sql = "SELECT infraction.id_inf, date_inf, no_immat, no_permis , SUM(delit.tarif) montant FROM infraction, comprend, delit WHERE infraction.id_inf = comprend.id_inf AND comprend.id_delit = delit.id_delit ";
        if (where !== "") {
            sql += " AND " + where;
        }
        sql += " GROUP BY comprend.id_inf";
        return sql;
    }

    all(): TInfrs { // renvoie le tableau d’objets contenant toutes les infractions
        return this.load(APIsql.sqlWeb.SQLloadData(this.prepare(""), []));
    }

    byIdInf(id_inf: string): UneInfr { // renvoie l’objet correspondant au département code_dept
        let infr = new UneInfr;
        const infrs: TInfrs =
            this.load(APIsql.sqlWeb.SQLloadData(this.prepare("infraction.id_inf = ?"), [id_inf]));
        const lesCles: string[] = Object.keys(infrs);
        // affecte les clés du tableau associatif « depts » dans le tableau de chaines « lesCles »
        if (lesCles.length > 0) {
            infr = infrs[lesCles[0]]; // récupérer le 1er élément du tableau associatif « depts »
        }
        return infr;
    }

    toArray(infrs: TInfrs): APIsql.TdataSet {
        // renvoie le tableau d’objets sous la forme d’un tableau de tableaux associatifs
        // pour un affichage dans un tableau HTML
        let T: APIsql.TdataSet = [];
        for (let id in infrs) {
            T.push(infrs[id].toArray());
        }
        return T;
    }

    delete(id_inf: string): boolean { // requête de suppression d’une salle dans la table
        let sql: string;
        sql = "DELETE FROM infraction WHERE id_inf = ?";
        return APIsql.sqlWeb.SQLexec(sql, [id_inf]); // requête de manipulation : utiliser SQLexec
    }
    insert(infraction: UneInfr): boolean { // requête d’ajout d’une salle dans la table
        let sql: string; // requête de manipulation : utiliser SQLexec
        sql = "INSERT INTO infraction(id_inf, date_inf, no_immat, no_permis) VALUES (?, ?, ?, ? )";
        return APIsql.sqlWeb.SQLexec(sql, [infraction.idInf, infraction.dateInf, infraction.noImmat, infraction.noPermis]);
    }
    update(infraction: UneInfr): boolean { // requête de modification d’une salle dans la table
        let sql: string;
        sql = "UPDATE infraction SET  date_inf = ?, no_immat = ?, no_permis = ?";
        sql += " WHERE id_inf = ?"; // requête de manipulation : utiliser SQLexec
        return APIsql.sqlWeb.SQLexec(sql, [infraction.dateInf, infraction.noImmat, infraction.noPermis, infraction.idInf]);
    }

}

export { connexion }
export { LesInfrs }
export { TInfrs }