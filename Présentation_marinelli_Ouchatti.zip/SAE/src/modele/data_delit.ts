import { connexion, APIsql } from "../modele/connexion.js"

export class ErreurNature extends Error {
    constructor(message:string){
        super(message)
        this.name = ("ErreurNature")
    }
 }

export class ErreurId extends Error {
    constructor(message:string){
        super(message)
        this.name = ("ErreurId")
    }
 }

export class ErreurTarif extends Error {
    constructor(message:string){
        super(message)
        this.name = ("ErreurTarif")
    }
 }

export class UnDelit {
    private _idDelit: string;
    private _Nature: string;
    private _Tarif: string;
    constructor(id_delit = "", nature = "", tarif = "") { // initialisation à l’instanciation
        this._idDelit = id_delit;
        this._Nature = nature;
        this._Tarif = tarif;
    }
    // définition des « getters » et des « setters » pour les attributs privés de la classe
    get idDelit(): string { return this._idDelit; }
    set idDelit(id_delit: string) { 
        if (Number.isInteger(id_delit)) {
            this._idDelit = id_delit; 
        }else{
            throw new ErreurId("L'Id doit etre un entier !")
        }
     }
    get Nature(): string { return this._Nature; }
    set Nature(nature: string) { 
        if (nature.length < 8){
            throw new ErreurNature("La nature doit au moins comporter 9 caractères !");
        }else{
            this._Nature = nature;
        }
     }
    get Tarif(): string { return this._Tarif; }
    set Tarif(tarif: string) { 
        let number = parseFloat(tarif);
        if (number <= 0) {
            throw new ErreurTarif("Le tarif doit être un réel supérieur à 0 !")
        }
        this._Tarif = tarif;
    }
    
    toArray(): APIsql.TtabAsso {
        // renvoie l’objet sous la forme d’un tableau associatif
        // pour un affichage dans une ligne d’un tableau HTML
        let tableau: APIsql.TtabAsso = {
            'idDelit': this._idDelit, 'Nature': this._Nature
            , Tarif: this._Tarif
        };
        return tableau;
    }
}

type TDelits = { [key: string]: UnDelit };

export class LesDelits { // définition de la classe gérant les données de la table TYPE_EQUIPT
    constructor() {
        // rien
    }

    private load(result: APIsql.TdataSet): TDelits {
        // à partir d’un TdataSet, conversion en tableau d’objets UnTypEquipt
        let delits: TDelits = {};
        for (let i = 0; i < result.length; i++) {
            const item: APIsql.TtabAsso = result[i];
            const delit = new UnDelit(item['id_delit'], item['nature'], item['tarif']);
            delits[delit.idDelit] = delit;// clé d’un élément du tableau : id equipt
        }
        return delits;
    }

    private prepare(where: string): string { // préparation de la requête avec ou sans restriction (WHERE)
        let sql: string;
        sql = "SELECT id_delit, nature, tarif";
        sql += " FROM delit"
        if (where.trim() !== "") {
            sql += " WHERE " + where;
        }
        sql += " ORDER BY nature ASC ";
        return sql;
    }
    all(): TDelits { // renvoie le tableau d’objets contenant tous les équipements
        return this.load(APIsql.sqlWeb.SQLloadData(this.prepare(""), []));
    }
    byIdDelit(id_delit: string): UnDelit { // renvoie l’objet correspondant à l’équipement id_equipt
        let delit = new UnDelit;
        const delits: TDelits = this.load(APIsql.sqlWeb.SQLloadData
            (this.prepare("id_delit = ?"), [id_delit]));
        const lesCles: string[] = Object.keys(delits);
        // affecte les clés du tableau associatif « typEquipts » dans le tableau de chaines « lesCles »
        if (lesCles.length > 0) {
            delit = delits[lesCles[0]]; // récupérer le 1er élément du tableau associatif « typEquipts »
        }
        return delit;
    }
    toArray(delits: TDelits): APIsql.TdataSet { // renvoie le tableau d’objets sous la forme
        // d’un tableau de tableaux associatifs pour un affichage dans un tableau HTML
        let T: APIsql.TdataSet = [];
        for (let id in delits) {
            T.push(delits[id].toArray());
        }
        return T;
    }
}

export class UnDelitByInfraction {
    private _tarif: string;
    private _unDelit: UnDelit;
    constructor(unDelit: UnDelit = null, tarif = "") {
        // attributs de TYPE_EQUIPT auxquelles on ajouter l’attribut « qte » de la relation « contient »
        this._unDelit = unDelit;
        this._tarif = tarif;
    }
    // définition des « getters » et des « setters » pour les attributs privés de la classe
    get tarif() { return this._tarif; }
    set tarif(tarif: string) { this._tarif = tarif; }
    get unDelit(): UnDelit { return this._unDelit; }
    set unDelit(unDelit: UnDelit) { this._unDelit = unDelit; }
    toArray(): APIsql.TtabAsso {
        // renvoie l’objet sous la forme d’un tableau associatif
        // pour un affichage dans une ligne d’un tableau HTML
        let tableau = this.unDelit.toArray(); // appel de la méthode « toArray » de « UnTypEquipt »
        tableau['tarif'] = this.tarif;
        return tableau;
    }
}


type TDelitsByInfraction = { [key: string]: UnDelitByInfraction };
// eslint-disable-next-line @typescript-eslint/no-unused-vars
class LesDelitsByInfraction {
    constructor() {
        // rien
    }
    private load(result: APIsql.TdataSet): TDelitsByInfraction {
        // à partir d’un TdataSet, conversion en tableau d’objets UnTypEquiptBySalle
        const delitsByInfraction: TDelitsByInfraction = {};
        const lesDelits = new LesDelits();
        for (let i = 0; i < result.length; i++) {
            const item: APIsql.TtabAsso = result[i];
            const unDelit = lesDelits.byIdDelit(item['id_delit']);
            const delitByInfraction = new UnDelitByInfraction(unDelit, item['tarif']);
            delitsByInfraction[delitByInfraction.unDelit.idDelit] = delitByInfraction;
        }
        return delitsByInfraction;
    }
    private prepare(where: string): string {
        let sql: string;
        sql = "SELECT delit.id_delit, nature, tarif ";
        sql += "FROM delit, comprend";
        if (where.trim() !== "") {
            sql += " WHERE comprend.id_delit = delit.id_delit AND " + where ;
        }
        sql += " ";
        return sql;
    }
    byIdInf(id_inf: string): TDelitsByInfraction {
        // renvoie le tableau d’objets contenant tous les équipements de la salle num salle
        return this.load(APIsql.sqlWeb.SQLloadData(this.prepare("id_inf = ?"), [id_inf]));
    }

    byIdInfIdDelit(id_inf: string, id_delit : string): UnDelitByInfraction {
        // renvoie l’objet de l’équipement id_equipt contenu dans la salle num_salle
        let delitByInfraction = new UnDelitByInfraction;
        let delitsByInfraction: TDelitsByInfraction = this.load(APIsql.sqlWeb.SQLloadData
            (this.prepare("id_inf = ? and id_delit = ?"), [id_inf, id_delit]));
        if (!delitsByInfraction[0] === undefined) {
            delitByInfraction = delitsByInfraction[0];
        }
        return delitByInfraction;
    }

    toArray(delits: TDelitsByInfraction): APIsql.TdataSet {
        let T: APIsql.TdataSet = [];
        for (let id in delits) {
            T.push(delits[id].toArray());
            delete T[T.length - 1].commentaire; // pas besoin du commentaire pour l'affichage dans le tableau
        }
        return T;
    }

    getTotalNbDelit(delits: TDelitsByInfraction): string {
        // renvoie la quantité totale d’équipements d’une salle
        let total = 0;
        for (let id in delits) {
            total += Number(delits[id].tarif);
        }
        return total.toString();
    }

    delete(id_inf: string): boolean { // requête de suppression des équipements d’une salle dans «contient»
        let sql: string;
        sql = "DELETE FROM comprend WHERE id_inf = ?";
        return APIsql.sqlWeb.SQLexec(sql, [id_inf]); // requête de manipulation : utiliser SQLexec
    }

    insert(id_inf: string, id_delit: TDelitsByInfraction): boolean {
        // requête d’ajout des équipements avec une quantité dans « contient » installé dans « num_salle »
        let sql: string;
        let separateur = "";
        sql = "INSERT INTO comprend(id_inf, id_delit) VALUES ";
        for (let cle in id_delit) {
            sql += separateur + "('" + id_inf + "','" + id_delit[cle].unDelit.idDelit  + "')";
            separateur = ",";
        }
        return APIsql.sqlWeb.SQLexec(sql, []);
    }
}
export { connexion }
export { TDelits }
export { LesDelitsByInfraction }
export { TDelitsByInfraction }