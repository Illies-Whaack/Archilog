import { connexion, APIsql } from "../modele/connexion.js";
var UneInfr = /** @class */ (function () {
    function UneInfr(id_inf, date_inf, no_immat, no_permis, montant) {
        if (id_inf === void 0) { id_inf = ""; }
        if (date_inf === void 0) { date_inf = ""; }
        if (no_immat === void 0) { no_immat = ""; }
        if (no_permis === void 0) { no_permis = ""; }
        if (montant === void 0) { montant = ""; }
        this._idInf = id_inf;
        this._dateInf = date_inf;
        this._noImmat = no_immat;
        this._noPermis = no_permis;
        this._Montant = montant;
    }
    Object.defineProperty(UneInfr.prototype, "idInf", {
        get: function () { return this._idInf; },
        set: function (id_inf) { this._idInf = id_inf; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(UneInfr.prototype, "dateInf", {
        get: function () { return this._dateInf; },
        set: function (date_inf) { this._dateInf = date_inf; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(UneInfr.prototype, "noImmat", {
        get: function () { return this._noImmat; },
        set: function (no_immat) { this._noImmat = no_immat; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(UneInfr.prototype, "noPermis", {
        get: function () { return this._noPermis; },
        set: function (no_permis) { this._noPermis = no_permis; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(UneInfr.prototype, "Montant", {
        get: function () { return this._Montant; },
        set: function (montant) { this._Montant = montant; },
        enumerable: false,
        configurable: true
    });
    UneInfr.prototype.toArray = function () {
        // pour un affichage dans une ligne d’un tableau HTML
        var tableau = {
            'idInf': this.idInf, 'dateInf': this.dateInf,
            'noImmat': this.noImmat, 'noPermis': this.noPermis, 'Montant': this.Montant
        };
        return tableau;
    };
    return UneInfr;
}());
var LesInfrs = /** @class */ (function () {
    function LesInfrs() {
        //rien
    }
    LesInfrs.prototype.idExiste = function (id_inf) {
        // renvoie le test d’existence d’une salle dans la table
        // sert pour l’ajout d’une nouvelle salle
        return (APIsql.sqlWeb.SQLloadData("SELECT id_inf FROM infraction WHERE id_inf=?", [id_inf]).length > 0);
    };
    LesInfrs.prototype.load = function (result) {
        var infrs = {};
        for (var i = 0; i < result.length; i++) {
            var item = result[i];
            var infr = new UneInfr(item['id_inf'], item['date_inf'], item['no_immat'], item['no_permis'], item['montant']);
            infrs[infr.idInf] = infr;
        }
        return infrs;
    };
    LesInfrs.prototype.prepare = function (where) {
        var sql;
        sql = "SELECT infraction.id_inf, date_inf, no_immat, no_permis , SUM(delit.tarif) montant FROM infraction, comprend, delit WHERE infraction.id_inf = comprend.id_inf AND comprend.id_delit = delit.id_delit ";
        if (where !== "") {
            sql += " AND " + where;
        }
        sql += " GROUP BY comprend.id_inf";
        return sql;
    };
    LesInfrs.prototype.all = function () {
        return this.load(APIsql.sqlWeb.SQLloadData(this.prepare(""), []));
    };
    LesInfrs.prototype.byIdInf = function (id_inf) {
        var infr = new UneInfr;
        var infrs = this.load(APIsql.sqlWeb.SQLloadData(this.prepare("infraction.id_inf = ?"), [id_inf]));
        var lesCles = Object.keys(infrs);
        // affecte les clés du tableau associatif « depts » dans le tableau de chaines « lesCles »
        if (lesCles.length > 0) {
            infr = infrs[lesCles[0]]; // récupérer le 1er élément du tableau associatif « depts »
        }
        return infr;
    };
    LesInfrs.prototype.toArray = function (infrs) {
        // renvoie le tableau d’objets sous la forme d’un tableau de tableaux associatifs
        // pour un affichage dans un tableau HTML
        var T = [];
        for (var id in infrs) {
            T.push(infrs[id].toArray());
        }
        return T;
    };
    LesInfrs.prototype["delete"] = function (id_inf) {
        var sql;
        sql = "DELETE FROM infraction WHERE id_inf = ?";
        return APIsql.sqlWeb.SQLexec(sql, [id_inf]); // requête de manipulation : utiliser SQLexec
    };
    LesInfrs.prototype.insert = function (infraction) {
        var sql; // requête de manipulation : utiliser SQLexec
        sql = "INSERT INTO infraction(id_inf, date_inf, no_immat, no_permis) VALUES (?, ?, ?, ? )";
        return APIsql.sqlWeb.SQLexec(sql, [infraction.idInf, infraction.dateInf, infraction.noImmat, infraction.noPermis]);
    };
    LesInfrs.prototype.update = function (infraction) {
        var sql;
        sql = "UPDATE infraction SET  date_inf = ?, no_immat = ?, no_permis = ?";
        sql += " WHERE id_inf = ?"; // requête de manipulation : utiliser SQLexec
        return APIsql.sqlWeb.SQLexec(sql, [infraction.dateInf, infraction.noImmat, infraction.noPermis, infraction.idInf]);
    };
    return LesInfrs;
}());
export { connexion };
export { UneInfr };
export { LesInfrs };
//# sourceMappingURL=data_infraction.js.map