import * as APIsql from "../modele/sqlWeb.js";
APIsql.sqlWeb.init("https://devweb.iutmetz.univ-lorraine.fr/~lorain6u/ihm/SAE/SAE/vue/", "https://devweb.iutmetz.univ-lorraine.fr/~nitschke5/ihm/IHM_API/");
var Connexion = /** @class */ (function () {
    function Connexion() {
        this.init();
    }
    Connexion.prototype.init = function () {
        // à adapter avec voter nom de base et vos identifiants de connexion
        APIsql.sqlWeb.bdOpen('devbdd.iutmetz.univ-lorraine.fr', '3306', 'lorain6u_SAE', 'lorain6u_appli', '32108297', 'utf8');
    };
    return Connexion;
}());
var connexion = new Connexion;
export { connexion, APIsql };
//# sourceMappingURL=connexion.js.map