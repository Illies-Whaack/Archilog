import { connexion, APIsql } from "../modele/connexion.js";
var UnCond = /** @class */ (function () {
    function UnCond(no_permis, date_permis, nom, prenom) {
        if (no_permis === void 0) { no_permis = ""; }
        if (date_permis === void 0) { date_permis = ""; }
        if (nom === void 0) { nom = ""; }
        if (prenom === void 0) { prenom = ""; }
        // initialisation à l’instanciation
        this._noPermis = no_permis;
        this._datePermis = date_permis;
        this._Nom = nom;
        this._Prenom = prenom;
    }
    Object.defineProperty(UnCond.prototype, "noPermis", {
        // définition des « getters » et des « setters » pour la lecture/écriture des attributs privés de la classe
        get: function () { return this._noPermis; },
        set: function (no_permis) { this._noPermis = no_permis; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(UnCond.prototype, "datePermis", {
        get: function () { return this._datePermis; },
        set: function (date_permis) { this._datePermis = date_permis; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(UnCond.prototype, "Nom", {
        get: function () { return this._Nom; },
        set: function (nom) { this._Nom = nom; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(UnCond.prototype, "Prenom", {
        get: function () { return this._Prenom; },
        set: function (prenom) { this._Prenom = prenom; },
        enumerable: false,
        configurable: true
    });
    UnCond.prototype.toArray = function () {
        // pour un affichage dans une ligne d’un tableau HTML
        var tableau = {
            'noPermis': this.noPermis, 'datePermis': this.datePermis, 'Nom': this.Nom,
            'Prenom': this.Prenom
        };
        return tableau;
    };
    return UnCond;
}());
var LesConds = /** @class */ (function () {
    function LesConds() {
        // rien
    }
    LesConds.prototype.load = function (result) {
        // à partir d’un TdataSet, conversion en tableau d’objets UnDept
        var conds = {};
        for (var i = 0; i < result.length; i++) {
            var item = result[i];
            var cond = new UnCond(item['no_permis'], item['date_permis'], item['nom'], item['prenom']);
            conds[cond.noPermis] = cond; // clé d’un élément du tableau : code dépt
        }
        return conds;
    };
    LesConds.prototype.prepare = function (where) {
        var sql;
        sql = "SELECT no_permis, date_permis, prenom, nom FROM conducteur ";
        if (where !== "") {
            sql += " WHERE " + where;
        }
        return sql;
    };
    LesConds.prototype.all = function () {
        return this.load(APIsql.sqlWeb.SQLloadData(this.prepare(""), []));
    };
    LesConds.prototype.ByNoPermis = function (no_permis) {
        var cond = new UnCond;
        var conds = this.load(APIsql.sqlWeb.SQLloadData(this.prepare("no_permis = ?"), [no_permis]));
        var lesCles = Object.keys(conds);
        // affecte les clés du tableau associatif « depts » dans le tableau de chaines « lesCles »
        if (lesCles.length > 0) {
            cond = conds[lesCles[0]]; // récupérer le 1er élément du tableau associatif « depts »
        }
        return cond;
    };
    LesConds.prototype.toArray = function (conds) {
        // renvoie le tableau d’objets sous la forme d’un tableau de tableaux associatifs
        // pour un affichage dans un tableau HTML
        var T = [];
        for (var id in conds) {
            T.push(conds[id].toArray());
        }
        return T;
    };
    return LesConds;
}());
export { connexion };
export { UnCond };
export { LesConds };
//# sourceMappingURL=data_conducteur.js.map