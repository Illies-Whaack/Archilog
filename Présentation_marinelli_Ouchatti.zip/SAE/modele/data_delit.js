import { connexion, APIsql } from "../modele/connexion.js";
var UnDelit = /** @class */ (function () {
    function UnDelit(id_delit, nature, tarif) {
        if (id_delit === void 0) { id_delit = ""; }
        if (nature === void 0) { nature = ""; }
        if (tarif === void 0) { tarif = ""; }
        this._idDelit = id_delit;
        this._Nature = nature;
        this._Tarif = tarif;
    }
    Object.defineProperty(UnDelit.prototype, "idDelit", {
        // définition des « getters » et des « setters » pour les attributs privés de la classe
        get: function () { return this._idDelit; },
        set: function (id_delit) { this._idDelit = id_delit; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(UnDelit.prototype, "Nature", {
        get: function () { return this._Nature; },
        set: function (nature) { this._Nature = nature; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(UnDelit.prototype, "Tarif", {
        get: function () { return this._Tarif; },
        set: function (tarif) { this._Tarif = tarif; },
        enumerable: false,
        configurable: true
    });
    UnDelit.prototype.toArray = function () {
        // renvoie l’objet sous la forme d’un tableau associatif
        // pour un affichage dans une ligne d’un tableau HTML
        var tableau = {
            'idDelit': this._idDelit, 'Nature': this._Nature,
            'Tarif': this._Tarif
        };
        return tableau;
    };
    return UnDelit;
}());
var LesDelits = /** @class */ (function () {
    function LesDelits() {
        // rien
    }
    LesDelits.prototype.load = function (result) {
        // à partir d’un TdataSet, conversion en tableau d’objets UnTypEquipt
        var delits = {};
        for (var i = 0; i < result.length; i++) {
            var item = result[i];
            var delit = new UnDelit(item['id_delit'], item['nature'], item['tarif']);
            delits[delit.idDelit] = delit; // clé d’un élément du tableau : id equipt
        }
        return delits;
    };
    LesDelits.prototype.prepare = function (where) {
        var sql;
        sql = "SELECT id_delit, nature, tarif";
        sql += " FROM delit";
        if (where.trim() !== "") {
            sql += " WHERE " + where;
        }
        sql += " ORDER BY nature ASC ";
        return sql;
    };
    LesDelits.prototype.all = function () {
        return this.load(APIsql.sqlWeb.SQLloadData(this.prepare(""), []));
    };
    LesDelits.prototype.byIdDelit = function (id_delit) {
        var delit = new UnDelit;
        var delits = this.load(APIsql.sqlWeb.SQLloadData(this.prepare("id_delit = ?"), [id_delit]));
        var lesCles = Object.keys(delits);
        // affecte les clés du tableau associatif « typEquipts » dans le tableau de chaines « lesCles »
        if (lesCles.length > 0) {
            delit = delits[lesCles[0]]; // récupérer le 1er élément du tableau associatif « typEquipts »
        }
        return delit;
    };
    LesDelits.prototype.toArray = function (delits) {
        // d’un tableau de tableaux associatifs pour un affichage dans un tableau HTML
        var T = [];
        for (var id in delits) {
            T.push(delits[id].toArray());
        }
        return T;
    };
    return LesDelits;
}());
var UnDelitByInfraction = /** @class */ (function () {
    function UnDelitByInfraction(unDelit, tarif) {
        if (unDelit === void 0) { unDelit = null; }
        if (tarif === void 0) { tarif = ""; }
        // attributs de TYPE_EQUIPT auxquelles on ajouter l’attribut « qte » de la relation « contient »
        this._unDelit = unDelit;
        this._tarif = tarif;
    }
    Object.defineProperty(UnDelitByInfraction.prototype, "tarif", {
        // définition des « getters » et des « setters » pour les attributs privés de la classe
        get: function () { return this._tarif; },
        set: function (tarif) { this._tarif = tarif; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(UnDelitByInfraction.prototype, "unDelit", {
        get: function () { return this._unDelit; },
        set: function (unDelit) { this._unDelit = unDelit; },
        enumerable: false,
        configurable: true
    });
    UnDelitByInfraction.prototype.toArray = function () {
        // renvoie l’objet sous la forme d’un tableau associatif
        // pour un affichage dans une ligne d’un tableau HTML
        var tableau = this.unDelit.toArray(); // appel de la méthode « toArray » de « UnTypEquipt »
        tableau['tarif'] = this.tarif;
        return tableau;
    };
    return UnDelitByInfraction;
}());
// eslint-disable-next-line @typescript-eslint/no-unused-vars
var LesDelitsByInfraction = /** @class */ (function () {
    function LesDelitsByInfraction() {
        // rien
    }
    LesDelitsByInfraction.prototype.load = function (result) {
        // à partir d’un TdataSet, conversion en tableau d’objets UnTypEquiptBySalle
        var delitsByInfraction = {};
        var lesDelits = new LesDelits();
        for (var i = 0; i < result.length; i++) {
            var item = result[i];
            var unDelit = lesDelits.byIdDelit(item['id_delit']);
            var delitByInfraction = new UnDelitByInfraction(unDelit, item['tarif']);
            delitsByInfraction[delitByInfraction.unDelit.idDelit] = delitByInfraction;
        }
        return delitsByInfraction;
    };
    LesDelitsByInfraction.prototype.prepare = function (where) {
        var sql;
        sql = "SELECT delit.id_delit, nature, tarif ";
        sql += "FROM delit, comprend";
        if (where.trim() !== "") {
            sql += " WHERE comprend.id_delit = delit.id_delit AND " + where;
        }
        sql += " ";
        return sql;
    };
    LesDelitsByInfraction.prototype.byIdInf = function (id_inf) {
        // renvoie le tableau d’objets contenant tous les équipements de la salle num salle
        return this.load(APIsql.sqlWeb.SQLloadData(this.prepare("id_inf = ?"), [id_inf]));
    };
    LesDelitsByInfraction.prototype.byIdInfIdDelit = function (id_inf, id_delit) {
        // renvoie l’objet de l’équipement id_equipt contenu dans la salle num_salle
        var delitByInfraction = new UnDelitByInfraction;
        var delitsByInfraction = this.load(APIsql.sqlWeb.SQLloadData(this.prepare("id_inf = ? and id_delit = ?"), [id_inf, id_delit]));
        if (!delitsByInfraction[0] === undefined) {
            delitByInfraction = delitsByInfraction[0];
        }
        return delitByInfraction;
    };
    LesDelitsByInfraction.prototype.toArray = function (delits) {
        var T = [];
        for (var id in delits) {
            T.push(delits[id].toArray());
            delete T[T.length - 1].commentaire; // pas besoin du commentaire pour l'affichage dans le tableau
        }
        return T;
    };
    LesDelitsByInfraction.prototype.getTotalNbDelit = function (delits) {
        // renvoie la quantité totale d’équipements d’une salle
        var total = 0;
        for (var id in delits) {
            total += Number(delits[id].tarif);
        }
        return total.toString();
    };
    LesDelitsByInfraction.prototype["delete"] = function (id_inf) {
        var sql;
        sql = "DELETE FROM comprend WHERE id_inf = ?";
        return APIsql.sqlWeb.SQLexec(sql, [id_inf]); // requête de manipulation : utiliser SQLexec
    };
    LesDelitsByInfraction.prototype.insert = function (id_inf, id_delit) {
        // requête d’ajout des équipements avec une quantité dans « contient » installé dans « num_salle »
        var sql;
        var separateur = "";
        sql = "INSERT INTO comprend(id_inf, id_delit) VALUES ";
        for (var cle in id_delit) {
            sql += separateur + "('" + id_inf + "','" + id_delit[cle].unDelit.idDelit + "')";
            separateur = ",";
        }
        return APIsql.sqlWeb.SQLexec(sql, []);
    };
    return LesDelitsByInfraction;
}());
export { connexion };
export { UnDelit };
export { LesDelits };
export { LesDelitsByInfraction };
export { UnDelitByInfraction };
//# sourceMappingURL=data_delit.js.map