import { connexion, APIsql } from "../modele/connexion.js";
var UnVehic = /** @class */ (function () {
    function UnVehic(no_immat, date_immat, modele, marque, no_permis, nom, prenom, date_permis) {
        if (no_immat === void 0) { no_immat = ""; }
        if (date_immat === void 0) { date_immat = ""; }
        if (modele === void 0) { modele = ""; }
        if (marque === void 0) { marque = ""; }
        if (no_permis === void 0) { no_permis = ""; }
        if (nom === void 0) { nom = ""; }
        if (prenom === void 0) { prenom = ""; }
        if (date_permis === void 0) { date_permis = ""; }
        // initialisation à l’instanciation
        this._noImmat = no_immat;
        this._dateImmat = date_immat;
        this._Modele = modele;
        this._Marque = marque;
        this._noPermis = no_permis;
        this._nom = nom;
        this._prenom = prenom;
        this._datePermis = date_permis;
    }
    Object.defineProperty(UnVehic.prototype, "noImmat", {
        // définition des « getters » et des « setters » pour la lecture/écriture des attributs privés de la classe
        get: function () { return this._noImmat; },
        set: function (no_immat) { this._noImmat = no_immat; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(UnVehic.prototype, "dateImmat", {
        get: function () { return this._dateImmat; },
        set: function (date_immat) { this._dateImmat = date_immat; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(UnVehic.prototype, "Modele", {
        get: function () { return this._Modele; },
        set: function (modele) { this._Modele = modele; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(UnVehic.prototype, "Marque", {
        get: function () { return this._Marque; },
        set: function (marque) { this._Marque = marque; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(UnVehic.prototype, "nom", {
        get: function () { return this._nom; },
        set: function (nom) { this._nom = nom; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(UnVehic.prototype, "noPermis", {
        get: function () { return this._noPermis; },
        set: function (no_permis) { this._noPermis = no_permis; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(UnVehic.prototype, "prenom", {
        get: function () { return this._prenom; },
        set: function (prenom) { this._prenom = prenom; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(UnVehic.prototype, "datePermis", {
        get: function () { return this._datePermis; },
        set: function (date_permis) { this._datePermis = date_permis; },
        enumerable: false,
        configurable: true
    });
    UnVehic.prototype.toArray = function () {
        // pour un affichage dans une ligne d’un tableau HTML
        var tableau = { 'noImmat': this.noImmat, 'dateImmat': this.dateImmat, 'Modele': this.Modele, 'Marque': this.Marque, 'noPermis': this.noPermis, 'nom': this.nom, 'prenom': this.prenom, 'datePermis': this.datePermis };
        return tableau;
    };
    return UnVehic;
}());
var LesVehics = /** @class */ (function () {
    function LesVehics() {
        // rien
    }
    LesVehics.prototype.idExiste = function (no_immat) {
        // renvoie le test d’existence d’une salle dans la table
        // sert pour l’ajout d’une nouvelle salle
        return (APIsql.sqlWeb.SQLloadData("SELECT no_immat FROM vehicule WHERE no_immat=?", [no_immat]).length > 0);
    };
    LesVehics.prototype.load = function (result) {
        // à partir d’un TdataSet, conversion en tableau d’objets UnDept
        var vehics = {};
        for (var i = 0; i < result.length; i++) {
            var item = result[i];
            var vehic = new UnVehic(item['no_immat'], item['date_immat'], item['modele'], item['marque'], item['no_permis'], item['nom'], item['prenom'], item['date_permis']);
            vehics[vehic.noImmat] = vehic; // clé d’un élément du tableau : code dépt
        }
        return vehics;
    };
    LesVehics.prototype.prepare = function (where) {
        var sql;
        sql = "SELECT no_immat, date_immat, modele, marque, vehicule.no_permis, nom, prenom, date_permis FROM vehicule, conducteur ";
        if (where !== "") {
            sql += " WHERE vehicule.no_permis = conducteur.no_permis AND " + where;
        }
        return sql;
    };
    LesVehics.prototype.all = function () {
        return this.load(APIsql.sqlWeb.SQLloadData(this.prepare(""), []));
    };
    LesVehics.prototype.byNoImmat = function (no_immat) {
        var vehic = new UnVehic;
        var vehics = this.load(APIsql.sqlWeb.SQLloadData(this.prepare("no_immat = ?"), [no_immat]));
        var lesCles = Object.keys(vehics);
        // affecte les clés du tableau associatif « depts » dans le tableau de chaines « lesCles »
        if (lesCles.length > 0) {
            vehic = vehics[lesCles[0]]; // récupérer le 1er élément du tableau associatif « depts »
        }
        return vehic;
    };
    LesVehics.prototype.toArray = function (vehics) {
        // renvoie le tableau d’objets sous la forme d’un tableau de tableaux associatifs
        // pour un affichage dans un tableau HTML
        var T = [];
        for (var id in vehics) {
            T.push(vehics[id].toArray());
        }
        return T;
    };
    return LesVehics;
}());
export { connexion };
export { UnVehic };
export { LesVehics };
//# sourceMappingURL=data_vehicule.js.map