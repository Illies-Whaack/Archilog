import { vueInfrListe } from "./class_infraction_liste.js";
vueInfrListe.init({ divTitre: document.querySelector('[id=div_infraction_liste_titre]'),
    btnAjouter: document.querySelector('[id=btn_infraction_ajouter]'),
    tableInfr: document.querySelector('[id=table_infraction]')
});
//# sourceMappingURL=infraction_liste.js.map