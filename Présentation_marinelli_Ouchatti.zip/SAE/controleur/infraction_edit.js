import { vueInfractionEdit } from "../controleur/class_infraction_edit.js";
vueInfractionEdit.init({
    divDetail: document.querySelector('[id=div_infraction_detail]'),
    divTitre: document.querySelector('[id=div_infraction_titre]'),
    edtNum: document.querySelector('[id=edt_infraction_num]'),
    edtDate: document.querySelector('[id=edt_infraction_date]'),
    edtImmat: document.querySelector('[id=edt_immat]'),
    edtPermis: document.querySelector('[id=edt_permis]'),
    btnRetour: document.querySelector('[id=btn_infraction_retour]'),
    btnValider: document.querySelector('[id=btn_infraction_valider]'),
    btnAnnuler: document.querySelector('[id=btn_infraction_annuler]'),
    btnAjouterDelit: document.querySelector('[id=btn_infraction_ajouter]'),
    lblImmatErreur: document.querySelector('[id=lbl_erreur_immat]'),
    lblDelitByInfErreur: document.querySelector('[id=lbl_erreur_delit]'),
    lblDetailInfraction1: document.querySelector('[id=lbl_infraction_detail2]'),
    lblDetailInfraction2: document.querySelector('[id=lbl_infraction_detail1]'),
    lblDetailInfraction3: document.querySelector('[id=lbl_conducteur_detail]'),
    divInfractionDelit: document.querySelector('[id=div_infraction_délit]'),
    divInfractionDelitEdit: document.querySelector('[id=div_infraction_délit_edit]'),
    lblTotal: document.querySelector('[id=lbl_infraction_total]'),
    tableDelits: document.querySelector('[id=table_delits]'),
    listeDelits: document.querySelector('[id=select_delit]'),
    lblErreurDate: document.querySelector('[id=lbl_erreur_date]')
});
//# sourceMappingURL=infraction_edit.js.map