import { LesInfrs } from "../modele/data_infraction.js";
import { LesConds } from "../modele/data_conducteur.js";
var VueInfrListe = /** @class */ (function () {
    function VueInfrListe() {
    }
    Object.defineProperty(VueInfrListe.prototype, "form", {
        get: function () { return this._form; },
        enumerable: false,
        configurable: true
    });
    VueInfrListe.prototype.init = function (form) {
        this._form = form;
        var lesInfrs = new LesInfrs;
        var lesConds = new LesConds();
        var data = lesInfrs.all();
        this.form.divTitre.textContent = 'Liste des infractions'; // construction du titre
        var _loop_1 = function (num) {
            var uneInfr = data[num];
            var date = new Date(uneInfr.dateInf);
            var dateFR = date.toLocaleDateString('fr-FR');
            uneInfr.dateInf = dateFR;
            var tr = this_1.form.tableInfr.insertRow(); // création nlle ligne dans tableau
            var balisea = void 0; // déclaration balise <a>
            // création balise <a> pour appel page visualisation du détail de la salle
            balisea = document.createElement("a");
            balisea.classList.add('img_visu'); // définition class contenant l’image (voir css)
            balisea.onclick = function () { vueInfrListe.detailInfrClick(uneInfr.idInf); };
            tr.insertCell().appendChild(balisea); // création nlle cellule dans ligne
            tr.insertCell().textContent = uneInfr.idInf;
            tr.insertCell().textContent = uneInfr.dateInf;
            tr.insertCell().textContent = uneInfr.noImmat;
            tr.insertCell().textContent = lesConds.ByNoPermis(uneInfr.noPermis).noPermis + " " + lesConds.ByNoPermis(uneInfr.noPermis).Prenom + " " + lesConds.ByNoPermis(uneInfr.noPermis).Nom;
            tr.insertCell().textContent = "";
            tr.insertCell().textContent = uneInfr.Montant;
            // création balise <a> pour appel page modification du détail de la salle
            balisea = document.createElement("a");
            balisea.classList.add('img_modification'); // définition class contenant l’image (voir css)
            balisea.onclick = function () { vueInfrListe.modifierInfrClick(uneInfr.idInf); };
            tr.insertCell().appendChild(balisea);
            // création balise <a> pour appel page suppression d'une salle
            balisea = document.createElement("a");
            balisea.classList.add('img_corbeille'); // définition class contenant l’image (voir css)
            balisea.onclick = function () { vueInfrListe.supprimerInfrClick(uneInfr.idInf); };
            tr.insertCell().appendChild(balisea);
        };
        var this_1 = this;
        for (var num in data) {
            _loop_1(num);
        }
        // définition événement onclick sur bouton "ajouter"
        this.form.btnAjouter.onclick = function () { vueInfrListe.ajouterInfrClick(); };
    };
    VueInfrListe.prototype.detailInfrClick = function (num) {
        // redirection vers « salle_edit.html »avec indication du statut « affi » et du numéro de salle
        location.href = "infraction_edit.html?affi&" + encodeURIComponent(num);
    };
    VueInfrListe.prototype.modifierInfrClick = function (num) {
        // redirection vers « salle_edit.html »avec indication du statut « modif » et du numéro de salle
        location.href = "infraction_edit.html?modif&" + encodeURIComponent(num);
    };
    VueInfrListe.prototype.supprimerInfrClick = function (num) {
        // redirection vers « salle_edit.html »avec indication du statut »suppr » et du numéro de salle
        location.href = "infraction_edit.html?suppr&" + encodeURIComponent(num);
    };
    VueInfrListe.prototype.ajouterInfrClick = function () {
        // redirection vers « salle_edit.html »avec indication du statut « ajout »
        location.href = "infraction_edit.html?ajout";
    };
    return VueInfrListe;
}());
var vueInfrListe = new VueInfrListe;
export { vueInfrListe };
//# sourceMappingURL=class_infraction_liste.js.map