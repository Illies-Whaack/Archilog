import { UneInfr, LesInfrs } from "../modele/data_infraction.js";
import { LesConds } from "../modele/data_conducteur.js";
import { LesVehics } from "../modele/data_vehicule";
import { UnDelitByInfraction, LesDelits, LesDelitsByInfraction } from "../modele/data_delit.js";
var VueInfractionEdit = /** @class */ (function () {
    function VueInfractionEdit() {
    }
    Object.defineProperty(VueInfractionEdit.prototype, "form", {
        get: function () { return this._form; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(VueInfractionEdit.prototype, "params", {
        get: function () { return this._params; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(VueInfractionEdit.prototype, "grille", {
        get: function () { return this._grille; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(VueInfractionEdit.prototype, "erreur", {
        get: function () { return this._erreur; },
        enumerable: false,
        configurable: true
    });
    VueInfractionEdit.prototype.initMsgErreur = function () {
        // les erreurs "champ vide", "valeur inconnue", "doublon"
        //sont les trois principales erreurs dans un formulaire
        // pour chaque champ à contrôler (événement onChange),
        //création des 3 messages d'erreur + message pour correct
        // avec chaîne vide si pas d'erreur générée pour un type d'erreur potentielle
        this._erreur = {
            edtImmat: {
                statut: 'vide',
                msg: {
                    correct: "",
                    vide: "L'immatriculation doit être renseignée.",
                    inconnu: "Immatriculation inconnue",
                    doublon: ""
                }
            },
            listeDelits: {
                statut: 'vide',
                msg: {
                    correct: "",
                    vide: "L'infraction doit comporter au moins un délit.",
                    inconnu: "",
                    doublon: ""
                }
            },
            edtPermis: {
                statut: 'vide',
                msg: {
                    correct: "",
                    vide: "",
                    inconnu: "Le vehicule est inconnu",
                    doublon: ""
                }
            },
            edtDate: {
                statut: 'vide',
                msg: {
                    correct: "",
                    vide: "La date saisie n'est pas valide",
                    inconnu: "",
                    doublon: ""
                }
            }
        };
    };
    VueInfractionEdit.prototype.init = function (form) {
        var _this = this;
        this._form = form;
        this._params = location.search.substring(1).split('&');
        // params[0] : mode affi, modif, suppr, ajout
        // params[1] : id en mode affi, modif, suppr
        this.form.divInfractionDelitEdit.hidden = true;
        this.initMsgErreur();
        var titre;
        switch (this.params[0]) {
            case 'suppr':
                titre = "Suppression d'une infraction";
                break;
            case 'ajout':
                titre = "Nouvelle infraction";
                break;
            case 'modif':
                titre = "Modification d'une infraction";
                break;
            default: titre = "Détail d'une infraction";
        }
        this.form.divTitre.textContent = titre;
        var lesInfrs = new LesInfrs;
        var affi = this.params[0] === 'affi';
        if (this.params[0] !== 'ajout') { // affi ou modif ou suppr
            var infr = lesInfrs.byIdInf(this._params[1]);
            this.form.edtNum.value = infr.idInf;
            this.form.edtDate.value = infr.dateInf;
            this.form.edtImmat.value = infr.noImmat;
            this.form.edtPermis.value = infr.noPermis;
            this.form.edtNum.readOnly = true;
            this.form.edtDate.readOnly = true;
            this.form.edtImmat.readOnly = affi;
            this.form.edtPermis.readOnly = affi;
            this.detailInfraction1(infr.noImmat);
            this.detailInfraction3(infr.noPermis);
        }
        if (this.params[0] === 'affi') {
            this.form.btnAjouterDelit.hidden = true;
        }
        this.affiDetail();
        if (this.params[0] === 'suppr') {
            // temporisation 1 seconde pour afficher les données de la salle avant demande de confirmation de la supression
            setTimeout(function () { _this.supprimer(_this.params[1]); }, 1000);
        }
        if (this.params[0] === 'ajout') {
            var lesInfrs_1 = new LesInfrs;
            var exist = true;
            var randomNum = void 0;
            while (exist) {
                randomNum = Math.floor(Math.random() * 100); // génère un nombre aléatoire entre 0 et 99
                exist = lesInfrs_1.idExiste(randomNum.toString());
                if (exist !== true) { // vérifie si le nombre existe déjà dans votre base de données
                    this.form.edtNum.value = randomNum.toString();
                    this.form.edtNum.readOnly = true;
                }
            }
            var d = new Date();
            this.form.edtDate.valueAsDate = d;
        }
        this.form.btnRetour.hidden = !affi;
        this.form.btnValider.hidden = affi;
        this.form.btnAnnuler.hidden = affi;
        this.form.edtImmat.onchange = function () { vueInfractionEdit.detailInfraction1(vueInfractionEdit.form.edtImmat.value); };
        this.form.edtPermis.onchange = function () { vueInfractionEdit.detailInfraction3(vueInfractionEdit.form.edtPermis.value); };
        this.form.btnRetour.onclick = function () { vueInfractionEdit.retourClick(); };
        this.form.btnAnnuler.onclick = function () { vueInfractionEdit.retourClick(); };
        this.form.btnValider.onclick = function () { vueInfractionEdit.validerClick(); };
        this.form.btnAjouterDelit.onclick = function () { vueInfractionEdit.ajouterDelitClick(); };
        this.form.listeDelits.onclick = function () { vueInfractionEdit.validerDelitClick(); };
    };
    VueInfractionEdit.prototype.detailInfraction1 = function (valeur) {
        var err = this.erreur.edtImmat;
        var lesVehic = new LesVehics;
        var detail = this.form.lblDetailInfraction2;
        detail.textContent = "";
        err.statut = "correct";
        var chaine = valeur.trim();
        if (chaine.length > 0) {
            var vehic = lesVehic.byNoImmat(chaine);
            if (vehic.noImmat !== "") { // département trouvé
                var date = new Date(vehic.dateImmat);
                var dateFR = date.toLocaleDateString('fr-FR');
                detail.textContent
                    = vehic.Marque + " " + vehic.Modele + "\r\n" + "immatriculé le " + dateFR;
            }
            else {
                err.statut = 'inconnu';
                detail.textContent = err.msg.inconnu;
            }
        }
        else
            err.statut = 'vide';
        detail = this.form.lblDetailInfraction1;
        detail.textContent = "";
        chaine = valeur.trim();
        if (chaine.length > 0) {
            var vehic = lesVehic.byNoImmat(chaine);
            if (vehic.noImmat !== "") { // département trouvé
                var date = new Date(vehic.datePermis);
                var dateFR = date.toLocaleDateString('fr-FR');
                detail.textContent
                    = "propriétaire : " + "\r\n" + vehic.nom + " " + vehic.prenom + "\r\n" + "permis obtenu le " + dateFR;
            }
        }
    };
    VueInfractionEdit.prototype.detailInfraction3 = function (valeur) {
        var err = this.erreur.edtPermis;
        var lesConds = new LesConds;
        var detail = this.form.lblDetailInfraction3;
        detail.textContent = "";
        err.statut = "correct";
        var chaine = valeur.trim();
        if (chaine.length > 0) {
            var cond = lesConds.ByNoPermis(chaine);
            if (cond.noPermis !== "") { // département trouvé
                var date = new Date(cond.datePermis);
                var dateFR = date.toLocaleDateString('fr-FR');
                detail.textContent
                    = cond.Nom + " " + cond.Prenom + "\r\n" + "permis obtenu le " + dateFR;
            }
            else {
                err.statut = 'inconnu';
                detail.textContent = err.msg.inconnu;
            }
        }
        else
            err.statut = 'vide';
    };
    VueInfractionEdit.prototype.affiDetail = function () {
        var lesDelitsByInfraction = new LesDelitsByInfraction();
        this._grille = lesDelitsByInfraction.byIdInf(this.params[1]);
        console.log(this.grille);
        this.affiGrilleDetail();
    };
    VueInfractionEdit.prototype.affiGrilleDetail = function () {
        while (this.form.tableDelits.rows.length > 1) {
            this.form.tableDelits.rows[1].remove();
        }
        var total = 0;
        var _loop_1 = function (id) {
            var unDelitByInfraction = this_1.grille[id];
            var tr = this_1.form.tableDelits.insertRow();
            tr.insertCell().textContent = unDelitByInfraction.unDelit.Nature;
            tr.insertCell().textContent = unDelitByInfraction.tarif;
            var affi = this_1.params[0] === 'affi';
            if (!affi) {
                var modif = this_1.params[0] === 'modif';
                var balisea = void 0; // déclaration balise <a>
                if (!modif) {
                    var ajout = this_1.params[0] === 'ajout';
                    if (!ajout) {
                        // création balise <a> pour appel modification équipement dans salle
                    }
                }
                // création balise <a> pour appel suppression équipement dans salle
                balisea = document.createElement("a");
                balisea.classList.add('img_corbeille');
                balisea.onclick = function () { vueInfractionEdit.supprimerDelitClick(id); };
                tr.insertCell().appendChild(balisea);
            }
            total += Number(unDelitByInfraction.tarif);
        };
        var this_1 = this;
        for (var id in this.grille) {
            _loop_1(id);
        }
        this.form.lblTotal.textContent = total.toString();
    };
    VueInfractionEdit.prototype.supprimer = function (idInf) {
        if (confirm("Confirmez-vous la suppression de l'infraction ?" + idInf)) {
            var lesDelitsByInfraction = new LesDelitsByInfraction();
            lesDelitsByInfraction["delete"](idInf); // suppression dans la base des equipements de la salle
            var lesInfrs = new LesInfrs;
            lesInfrs["delete"](idInf); // suppression dans la base de la salle
        }
        this.retourClick();
    };
    VueInfractionEdit.prototype.verifImmat = function (valeur) {
        var lesVehics = new LesVehics;
        var err = this.erreur.edtImmat;
        err.statut = "correct";
        var chaine = valeur.trim();
        if (chaine.length > 0) {
            if (!chaine.match(/^([a-zA-Z0-9]+)$/)) {
                // expression régulière qui teste si la chaîne ne contient rien d'autre
                // que des caractères alphabétiques minuscules ou majuscules et des chiffres
                this.erreur.edtImmat.statut = 'inconnu';
            }
            else if ((this.params[0] === 'ajout') && (lesVehics.idExiste(chaine))) {
                this.erreur.edtImmat.statut = 'doublon';
            }
        }
        else
            err.statut = 'vide';
    };
    VueInfractionEdit.prototype.verifListeDelit = function () {
        var err = this._erreur.listeDelits;
        err.statut = "correct";
        var cible = this._form.listeDelits;
        if (cible.value === "") {
            err.statut = 'vide';
        }
    };
    VueInfractionEdit.prototype.verifDate = function () {
        var err = this._erreur.edtDate;
        err.statut = "correct";
        var cible = this._form.edtDate;
        var d = new Date;
        if ((cible.valueAsDate >= d) || (cible.value === "")) {
            err.statut = 'vide';
        }
    };
    VueInfractionEdit.prototype.traiteErreur = function (uneErreur, zone) {
        var correct = true;
        zone.textContent = "";
        if (uneErreur.statut !== "correct") { // non correct ==> erreur
            if (uneErreur.msg[uneErreur.statut] !== '') { // erreur
                zone.textContent = uneErreur.msg[uneErreur.statut];
                correct = false;
            }
        }
        return correct;
    };
    VueInfractionEdit.prototype.validerClick = function () {
        var correct = true;
        this.verifImmat(this._form.edtImmat.value);
        this.verifListeDelit();
        this.verifDate();
        if (JSON.stringify(this.grille) === '{}') {
            this._erreur.listeDelits.statut = 'vide';
        }
        else
            this._erreur.listeDelits.statut = "correct";
        correct = this.traiteErreur(this._erreur.edtImmat, this.form.lblImmatErreur) && correct;
        correct = this.traiteErreur(this._erreur.listeDelits, this.form.lblDelitByInfErreur) && correct;
        correct = this.traiteErreur(this._erreur.edtDate, this.form.lblErreurDate) && correct;
        if (this.form.edtDate.value <= this.form.edtDate.valueAsDate.toDateString()) {
            correct = this.traiteErreur(this._erreur.edtDate, this.form.lblErreurDate) && correct;
        }
        var lesInfrs = new LesInfrs;
        var infr = new UneInfr;
        if (correct) {
            infr.idInf = this.form.edtNum.value;
            infr.dateInf = this.form.edtDate.value;
            infr.noImmat = this.form.edtImmat.value;
            infr.noPermis = this.form.edtPermis.value;
            if (this._params[0] === 'ajout') {
                lesInfrs.insert(infr);
            }
            else {
                lesInfrs.update(infr);
            }
            var lesDelitsByInfraction = new LesDelitsByInfraction;
            lesDelitsByInfraction["delete"](infr.idInf);
            lesDelitsByInfraction.insert(infr.idInf, this.grille);
            this.retourClick();
        }
    };
    VueInfractionEdit.prototype.retourClick = function () {
        location.href = "infraction_liste.html";
    };
    VueInfractionEdit.prototype.ajouterDelitClick = function () {
        this.afficherDelitEdit();
        // réinitialiser la liste des équipements à choisir
        this.form.listeDelits.length = 0;
        var lesDelits = new LesDelits;
        var data = lesDelits.all();
        var idDelits = [];
        for (var i in this._grille) {
            idDelits.push(this._grille[i].unDelit.idDelit);
        }
        for (var i in data) {
            var id = data[i].idDelit;
            if (idDelits.indexOf(id) === -1) { // pas dans la liste des équipements déjà dans la salle
                this._form.listeDelits.options.add(new Option(data[i].Nature, id)); // text, value
            }
        }
    };
    VueInfractionEdit.prototype.supprimerDelitClick = function (id) {
        if (confirm("Confirmez-vous le retrait de l'équipement de l'infraction ? ")) {
            delete (this._grille[id]);
            this.affiGrilleDetail();
        }
    };
    VueInfractionEdit.prototype.afficherDelitEdit = function () {
        this.form.divInfractionDelitEdit.hidden = false;
        this.form.divDetail.style.pointerEvents = 'none';
        this.form.divInfractionDelitEdit.style.pointerEvents = 'auto';
        this.form.btnAnnuler.hidden = true;
        this.form.btnValider.hidden = true;
    };
    VueInfractionEdit.prototype.cacherDelitEdit = function () {
        this.form.divInfractionDelitEdit.hidden = true;
        this.form.divDetail.style.pointerEvents = 'auto';
        this.form.btnAnnuler.hidden = false;
        this.form.btnValider.hidden = false;
    };
    VueInfractionEdit.prototype.validerDelitClick = function () {
        var correct = true;
        this.verifListeDelit();
        correct = this.traiteErreur(this._erreur.listeDelits, this.form.lblDelitByInfErreur) && correct;
        if (correct) {
            var lesDelits = new LesDelits;
            // ajout visuel de la ligne dans la grille tabulaire de la liste des équipements d'une salle
            var unDelit = lesDelits.byIdDelit(this._form.listeDelits.value);
            var unDelitByInfraction = new UnDelitByInfraction(unDelit, unDelit.Tarif);
            this._grille[unDelit.Nature] = unDelitByInfraction;
            this.affiGrilleDetail();
            this.annulerDelitClick();
        }
    };
    VueInfractionEdit.prototype.annulerDelitClick = function () {
        this.cacherDelitEdit();
    };
    return VueInfractionEdit;
}());
var vueInfractionEdit = new VueInfractionEdit;
export { vueInfractionEdit };
//# sourceMappingURL=class_infraction_edit.js.map