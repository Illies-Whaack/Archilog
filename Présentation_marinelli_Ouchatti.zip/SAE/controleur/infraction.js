"use strict";
var VueInventaire = /** @class */ (function () {
    function VueInventaire() {
    }
    VueInventaire.prototype.init = function () {
        location.href = "infraction_liste.html";
    };
    return VueInventaire;
}());
var vueInventaire = new VueInventaire;
vueInventaire.init();
//# sourceMappingURL=infraction.js.map