export class ErreurPermis extends Error {
    constructor(message:string){
        super(message)
        this.name = ("ErreurPermis")
    }
 }

 export class ErreurDate extends Error {
    constructor(message:string){
        super(message)
        this.name = ("ErreurDate")
    }
 }
 export class ErreurPrenom extends Error {
    constructor(message:string){
        super(message)
        this.name = ("ErreurPrenom")
    }
 }
 export class ErreurNom extends Error {
    constructor(message:string){
        super(message)
        this.name = ("ErreurNom")
    }
 }


export class UnCond { // définition de la classe gérant les données d’un département
    private _noPermis: string;
    private _datePermis: string;
    private _Nom: string;
    private _Prenom: string;
    constructor(no_permis = "", date_permis = "", nom = "", prenom = "") {
        // initialisation à l’instanciation
        this._noPermis = no_permis
        this._datePermis = date_permis
        this._Nom = nom
        this._Prenom = prenom

    }
    // définition des « getters » et des « setters » pour la lecture/écriture des attributs privés de la classe
    get noPermis(): string { return this._noPermis; }
    set noPermis(no_permis: string) { 
        if(no_permis[0].match(/^([a-zA-Z]+)$/)){
            if(no_permis[1].match(/^([a-zA-Z]+)$/)){
                if(no_permis[2].match(/^([0-9]+)$/)){
                    if(no_permis[3].match(/^([0-9]+)$/)){
                        this._noPermis = no_permis
                    }else{
                        throw new ErreurPermis("Le numéro permis n'est pas au bon format !")
                    }
                }else{
                    throw new ErreurPermis("Le numéro permis n'est pas au bon format !")
                }
            }else{
                throw new ErreurPermis("Le numéro permis n'est pas au bon format !")
            }
        }else{
            throw new ErreurPermis("Le numéro permis n'est pas au bon format !")
        }
     }
    get datePermis(): string { return this._datePermis; }
    set datePermis(date_permis: string) { 
        let tab = date_permis.split("-");
        if (tab.length != 3){
            throw new ErreurDate("La date n'est pas au bon format !")
        }
        let jour = parseInt(tab[2]);
        if (jour < 1 || jour > 31){
            throw new ErreurDate("La date n'est pas au bon format !")
        }
        let mois = parseInt(tab[1]);
        if (mois < 1 || mois > 12){
            throw new ErreurDate("La date n'est pas au bon format !")
        }
        let année = parseInt(tab[0]);
        if (année < 1 || année > 9999){
            throw new ErreurDate("La date n'est pas au bon format !")
        }
        for (let i = 0;i<tab[0].length - 1; i++){
            if (!tab[0][i].match(/^([0-9]+)$/)){
            throw new ErreurDate("La date n'est pas au bon format !")
            }
        }
        for (let i = 0;i<tab[1].length - 1; i++){
            if (!tab[1][i].match(/^([0-9]+)$/)){
            throw new ErreurDate("La date n'est pas au bon format !")
            }
        }
        for (let i = 0;i<tab[2].length - 1; i++){
            if (!tab[2][i].match(/^([0-9]+)$/)){
            throw new ErreurDate("La date n'est pas au bon format !")
            }
        }
        this._datePermis = date_permis;
     }
    get Nom(): string { return this._Nom; }
    set Nom(nom: string) { 
        if (nom.length < 2){
            throw new ErreurNom("Le modele n'est pas au bon format !") 
        }
        for (let i = 0; i < nom.length - 1; i++){
            if (!nom[i].match(/^([a-zA-Z" "-]+)$/)){
                throw new ErreurNom("Le modele n'est pas au bon format !") 
            }
        }
        this._Nom = nom
    }
    get Prenom(): string { return this._Prenom; }
    set Prenom(prenom: string) { 
        if (prenom.length < 2){
            throw new ErreurPrenom("Le modele n'est pas au bon format !") 
        }
        for (let i = 0; i < prenom.length - 1; i++){
            if (!prenom[i].match(/^([a-zA-Z0-9" "-]+)$/)){
                throw new ErreurPrenom("Le modele n'est pas au bon format !") 
            }
        }
        this._Prenom = prenom
     }
}