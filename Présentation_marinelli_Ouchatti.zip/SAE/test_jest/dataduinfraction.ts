export class ErreurId extends Error {
    constructor(message:string){
        super(message)
        this.name = ("ErreurId")
    }
 }

 export class ErreurDate extends Error {
    constructor(message:string){
        super(message)
        this.name = ("ErreurDate")
    }
 }

 export class ErreurImmat extends Error {
    constructor(message:string){
        super(message)
        this.name = ("ErreurImmat")
    }
 }

 export class ErreurPermis extends Error {
    constructor(message:string){
        super(message)
        this.name = ("ErreurPermis")
    }
 }

export class UneInfr {
    private _idInf: string
    private _dateInf: string;
    private _noImmat: string;
    private _noPermis: string;
    private _Montant : string

    constructor(id_inf = "", date_inf = "", no_immat = "", no_permis = "", montant = "") {
        this._idInf = id_inf
        this._dateInf = date_inf
        this._noImmat = no_immat
        this._noPermis = no_permis
        this._Montant = montant
    }

    get idInf(): string { return this._idInf; }
    set idInf(id_inf: string) { 
        if (Number.isInteger(id_inf)) {
            this._idInf = id_inf; 
        }else{
            throw new ErreurId("L'Id doit etre un entier !")
        }
     }
    get dateInf(): string { return this._dateInf; }
    set dateInf(date_inf: string) { 
        let tab = date_inf.split("-");
        if (tab.length != 3){
            throw new ErreurDate("La date n'est pas au bon format !")
        }
        let jour = parseInt(tab[2]);
        if (jour < 1 || jour > 31){
            throw new ErreurDate("La date n'est pas au bon format !")
        }
        let mois = parseInt(tab[1]);
        if (mois < 1 || mois > 12){
            throw new ErreurDate("La date n'est pas au bon format !")
        }
        let année = parseInt(tab[0]);
        if (année < 1 || année > 9999){
            throw new ErreurDate("La date n'est pas au bon format !")
        }
        for (let i = 0;i<tab[0].length - 1; i++){
            if (!tab[0][i].match(/^([0-9]+)$/)){
            throw new ErreurDate("La date n'est pas au bon format !")
            }
        }
        for (let i = 0;i<tab[1].length - 1; i++){
            if (!tab[1][i].match(/^([0-9]+)$/)){
            throw new ErreurDate("La date n'est pas au bon format !")
            }
        }
        for (let i = 0;i<tab[2].length - 1; i++){
            if (!tab[2][i].match(/^([0-9]+)$/)){
            throw new ErreurDate("La date n'est pas au bon format !")
            }
        }
        this._dateInf = date_inf;
     }
    get noImmat(): string { return this._noImmat; }
    set noImmat(no_immat: string) { 
        if(no_immat[0].match(/^([a-zA-Z]+)$/)){
            if(no_immat[1].match(/^([a-zA-Z]+)$/)){
                if(no_immat[2].match(/^([0-9]+)$/)){
                    if(no_immat[3].match(/^([0-9]+)$/)){
                        if(no_immat[4].match(/^([a-zA-Z]+)$/)){
                            if(no_immat[5].match(/^([a-zA-Z]+)$/)){
                                this._noImmat = no_immat;
                            }else{
                                throw new ErreurImmat("L'immatriculation n'est pas du bon format !");
                            }
                        }else{
                            throw new ErreurImmat("L'immatriculation n'est pas du bon format !");
                        }
                    }else{
                        throw new ErreurImmat("L'immatriculation n'est pas du bon format !");
                    }
                }else{
                    throw new ErreurImmat("L'immatriculation n'est pas du bon format !");
                }
            }else{
                throw new ErreurImmat("L'immatriculation n'est pas du bon format !");
            }
        }else{
            throw new ErreurImmat("L'immatriculation n'est pas du bon format !");
        }
     }
    get noPermis(): string { return this._noPermis; }
    set noPermis(no_permis: string) { 
        if(no_permis[0].match(/^([a-zA-Z]+)$/)){
            if(no_permis[1].match(/^([a-zA-Z]+)$/)){
                if(no_permis[2].match(/^([0-9]+)$/)){
                    if(no_permis[3].match(/^([0-9]+)$/)){
                        this._noPermis = no_permis
                    }else{
                        throw new ErreurPermis("Le numéro permis n'est pas au bon format !")
                    }
                }else{
                    throw new ErreurPermis("Le numéro permis n'est pas au bon format !")
                }
            }else{
                throw new ErreurPermis("Le numéro permis n'est pas au bon format !")
            }
        }else{
            throw new ErreurPermis("Le numéro permis n'est pas au bon format !")
        }
     }
    get Montant(): string { return this._Montant; }
    set Montant(montant: string) { this._Montant = montant; }
    
}