export class ErreurNature extends Error {
    constructor(message:string){
        super(message)
        this.name = ("ErreurNature")
    }
 }

export class ErreurId extends Error {
    constructor(message:string){
        super(message)
        this.name = ("ErreurId")
    }
 }

export class ErreurTarif extends Error {
    constructor(message:string){
        super(message)
        this.name = ("ErreurTarif")
    }
 }

export class UnDelit {
    private _idDelit: string;
    private _Nature: string;
    private _Tarif: string;
    constructor(id_delit = "", nature = "", tarif = "") { // initialisation à l’instanciation
        this._idDelit = id_delit;
        this._Nature = nature;
        this._Tarif = tarif;
    }
    // définition des « getters » et des « setters » pour les attributs privés de la classe
    get idDelit(): string { return this._idDelit; }
    set idDelit(id_delit: string) { 
        if (Number.isInteger(id_delit)) {
            this._idDelit = id_delit; 
        }else{
            throw new ErreurId("L'Id doit etre un entier !")
        }
     }
    get Nature(): string { return this._Nature; }
    set Nature(nature: string) { 
        if (nature.length < 8){
            throw new ErreurNature("La nature doit au moins comporter 9 caractères !");
        }else{
            this._Nature = nature;
        }
     }
    get Tarif(): string { return this._Tarif; }
    set Tarif(tarif: string) { 
        let number = parseFloat(tarif);
        if (number <= 0) {
            throw new ErreurTarif("Le tarif doit être un réel supérieur à 0 !")
        }
        this._Tarif = tarif;
    }
}
