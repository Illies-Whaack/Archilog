import { UnVehic,ErreurImmat, ErreurDate, ErreurMarque, ErreurModele, ErreurPermis } from "../test_jest/dataduvehicule";

test("test numéro Immat du bon format", () => {
    let immat = new UnVehic();
    try {
        immat.noImmat = "AZ23RT"
    }catch(e){
        expect(immat.noImmat).toBe("AZ23RT")
    }
});

test("test numéro Immat du mauvais format", () => {
    let immat = new UnVehic();
    try {
        immat.noImmat = "AZ235T"
    }catch(e){
        if (immat instanceof ErreurImmat) {
            console.log("Erreur de type ErreurImmat")
        }
    }
});

test("test Date du bon format", () => {
    let Date = new UnVehic();
    try {
        Date.dateImmat = "20-04-18"
    }catch(e){
        expect(Date.dateImmat).toBe("20-04-18")
    }
});

test("test Date du mauvais format", () => {
    let date = new UnVehic();
    try {
        date.dateImmat = "81236987/4932/234"
    }catch(e){
        if (date instanceof ErreurDate) {
            console.log("Erreur de type ErreurDate")
        }
    }
});

test("test marque au bon format", () => {
    let marque = new UnVehic();
    try {
        marque.Marque = "Citr oën"
    }catch(e){
        expect(marque.Marque).toBe("Citr oën")
    }
});

test("test marque au mauvais format", () => {
    let marque = new UnVehic();
    try {
        marque.Marque = "azd"
    }catch(e){
        if (marque instanceof ErreurMarque) {
            console.log("Erreur de type ErreurMarque")
        }
    }
});

test("test modele au bon format", () => {
    let modele = new UnVehic();
    try {
        modele.Modele = "C3"
    }catch(e){
        expect(modele.Modele).toBe("C3")
    }
});

test("test modele au bon format", () => {
    let modele = new UnVehic();
    try {
        modele.Marque = "a"
    }catch(e){
        if (modele instanceof ErreurModele) {
            console.log("Erreur de type ErreurMarque")
        }
    }
});

test("test numéro Permis du bon format", () => {
    let permis = new UnVehic();
    try {
        permis.noPermis = "RT43"
    }catch(e){
        expect(permis.noPermis).toBe("RT43")
    }
});

test("test numéro Permis du mauvais format", () => {
    let permis = new UnVehic();
    try {
        permis.noPermis = "a32R"
    }catch(e){
        if (e instanceof ErreurPermis) {
            console.log("Erreur de type ErreurImmat")
        }
    }
});