import { UneInfr,ErreurImmat, ErreurDate, ErreurId, ErreurPermis } from "../test_jest/dataduinfraction";

test("test numéro Immat du bon format", () => {
    let immat = new UneInfr();
    try {
        immat.noImmat = "AZ23RT"
    }catch(e){
        expect(immat.noImmat).toBe("AZ23RT")
    }
});

test("test numéro Immat du mauvais format", () => {
    let immat = new UneInfr();
    try {
        immat.noImmat = "AZ235T"
    }catch(e){
        if (immat instanceof ErreurImmat) {
            console.log("Erreur de type ErreurImmat")
        }
    }
});

test("test Date du bon format", () => {
    let Date = new UneInfr();
    try {
        Date.dateInf = "20-04-18"
    }catch(e){
        expect(Date.noImmat).toBe("20-04-18")
    }
});

test("test Date du mauvais format", () => {
    let immat = new UneInfr();
    try {
        immat.dateInf = "81236987/4932/234"
    }catch(e){
        if (immat instanceof ErreurDate) {
            console.log("Erreur de type ErreurDate")
        }
    }
});

test("test pour que l'id soit un entier", () => {
    let id= new UneInfr("2", "Excès de vitesse", "220,00");
    try{
        id.idInf = "2";
    }catch(e){
        expect(id.idInf).toBe("2")
    }
});

test("test pour que l'id ne soit pas un entier", () => {
    let id = new UneInfr("2", "Excès de vitesse", "220,00");
    try{
        id.idInf = "2,5";
    }catch(e){
        if (id instanceof ErreurId) {
            console.log("Erreur de type ErreurId")
        }
    }
});

test("test numéro Permis du bon format", () => {
    let permis = new UneInfr();
    try {
        permis.noPermis = "RT43"
    }catch(e){
        expect(permis.noPermis).toBe("RT43")
    }
});

test("test numéro Permis du mauvais format", () => {
    let permis = new UneInfr();
    try {
        permis.noPermis = "a32R"
    }catch(e){
        if (e instanceof ErreurPermis) {
            console.log("Erreur de type ErreurImmat")
        }
    }
});