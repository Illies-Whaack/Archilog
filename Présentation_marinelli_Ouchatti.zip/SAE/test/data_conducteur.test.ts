import { UnCond, ErreurDate, ErreurNom, ErreurPermis, ErreurPrenom } from "../test_jest/dataduconducteur"

test("test Date du bon format", () => {
    let Date = new UnCond();
    try {
        Date.datePermis = "20-04-18"
    }catch(e){
        expect(Date.datePermis).toBe("20-04-18")
    }
});

test("test Date du mauvais format", () => {
    let date = new UnCond();
    try {
        date.datePermis = "81236987/4932/234"
    }catch(e){
        if (date instanceof ErreurDate) {
            console.log("Erreur de type ErreurDate")
        }
    }
});

test("test nom au bon format", () => {
    let nom = new UnCond();
    try {
        nom.Nom = "Ouchatti"
    }catch(e){
        expect(nom.Nom).toBe("Ouchatti")
    }
});

test("test nom au mauvais format", () => {
    let nom = new UnCond();
    try {
        nom.Nom = "OC"
    }catch(e){
        if (nom instanceof ErreurNom) {
            console.log("Erreur de type ErreurNom")
        }
    }
});

test("test nom au bon format", () => {
    let prenom = new UnCond();
    try {
        prenom.Prenom = "Illies"
    }catch(e){
        expect(prenom.Prenom).toBe("Illies")
    }
});

test("test nom au mauvais format", () => {
    let prenom = new UnCond();
    try {
        prenom.Prenom = "Illies"
    }catch(e){
        if (prenom instanceof ErreurPrenom) {
            console.log("Erreur de type ErreurNom")
        }
    }
});

test("test numéro Permis du bon format", () => {
    let permis = new UnCond();
    try {
        permis.noPermis = "RT43"
    }catch(e){
        expect(permis.noPermis).toBe("RT43")
    }
});

test("test numéro Permis du mauvais format", () => {
    let permis = new UnCond();
    try {
        permis.noPermis = "a32R"
    }catch(e){
        if (e instanceof ErreurPermis) {
            console.log("Erreur de type ErreurImmat")
        }
    }
});