import { UnDelit, ErreurTarif, ErreurId, ErreurNature } from "../test_jest/datadudelit"

test("test du Tarif positif", () => {
    let tarif = new UnDelit("2", "Excès de vitesse", "220,00");
    try {
        tarif.Tarif = "27,00"
    }catch(e){
        expect(tarif.Tarif).toBe("27,00");
    }
});

test("test du Tarif négatif", () => {
    let tarif = new UnDelit("2", "Excès de vitesse", "220,00");
    try{
        tarif.Tarif = "-5,00";
    }catch(e){
        if (e instanceof ErreurTarif) {
            console.log("Erreur de type ErreurTarif");
        }
    }
});

test("test pour que l'id soit un entier", () => {
    let id= new UnDelit("2", "Excès de vitesse", "220,00");
    try{
        id.idDelit = "2";
    }catch(e){
        expect(id.idDelit).toBe("2")
    }
});

test("test pour que l'id ne soit pas un entier", () => {
    let id = new UnDelit("2", "Excès de vitesse", "220,00");
    try{
        id.idDelit = "2,5";
    }catch(e){
        if (id instanceof ErreurId) {
            console.log("Erreur de type ErreurId");
        }
    }
});

test("test la nature possède 9 caractères", () => {
    let nature= new UnDelit("2", "Excès de vitesse", "220,00");
    try{
        nature.Nature = "Excès de vitesse";
    }catch(e){
        expect(nature.Nature).toBe("Excès de vitesse"); 
    }
});

test("test pour que l'id ne soit pas un entier", () => {
    let id = new UnDelit("2,5", "Excès de vitesse", "220,00");
    try{
        id.idDelit = "Salut";
    }catch(e){
        if (id instanceof ErreurNature) {
            console.log("Erreur de type ErreurNature");
        }
    }
});
